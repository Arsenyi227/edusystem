#!/usr/bin/env bash
# =============================================================================
#  EduSystem — автоустановка на Debian 11/12
#  Использование: sudo bash install.sh [--domain example.com] [--port 3000]
# =============================================================================
set -euo pipefail

# ── Параметры ─────────────────────────────────────────────────────────────────
DOMAIN="localhost"
BACKEND_PORT=3000
DB_NAME="edudb"
DB_USER="eduuser"
DB_PASS="$(openssl rand -hex 16)"
JWT_SECRET="$(openssl rand -hex 32)"
APP_DIR="/opt/edusystem"
NODE_VERSION="20"

while [[ $# -gt 0 ]]; do
  case $1 in
    --domain) DOMAIN="$2"; shift 2 ;;
    --port)   BACKEND_PORT="$2"; shift 2 ;;
    *) echo "Неизвестный параметр: $1"; exit 1 ;;
  esac
done

# ── Цвета ─────────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}✓${NC} $*"; }
info() { echo -e "${YELLOW}→${NC} $*"; }
err()  { echo -e "${RED}✗${NC} $*"; exit 1; }

[[ $EUID -ne 0 ]] && err "Запустите скрипт с правами root: sudo bash install.sh"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║       EduSystem — Установка              ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. Обновление системы ─────────────────────────────────────────────────────
info "Обновление списка пакетов..."
apt-get update -qq
apt-get install -y -qq curl wget gnupg2 lsb-release ca-certificates \
  openssl nginx git build-essential
ok "Базовые пакеты установлены"

# ── 2. Node.js ────────────────────────────────────────────────────────────────
if ! command -v node &>/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d 'v')" -lt 18 ]]; then
  info "Установка Node.js ${NODE_VERSION}..."
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_VERSION}.x" | bash - &>/dev/null
  apt-get install -y -qq nodejs
  ok "Node.js $(node -v) установлен"
else
  ok "Node.js $(node -v) уже установлен"
fi

# ── 3. PostgreSQL ─────────────────────────────────────────────────────────────
if ! command -v psql &>/dev/null; then
  info "Установка PostgreSQL..."
  apt-get install -y -qq postgresql postgresql-contrib
  systemctl enable postgresql --quiet
  systemctl start postgresql
  ok "PostgreSQL установлен"
else
  ok "PostgreSQL уже установлен"
  systemctl start postgresql || true
fi

# ── 4. База данных ────────────────────────────────────────────────────────────
info "Настройка базы данных..."
sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${DB_USER}') THEN
    CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';
  ELSE
    ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';
  END IF;
END \$\$;
SELECT 'CREATE DATABASE ${DB_NAME} OWNER ${DB_USER}'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${DB_NAME}') \gexec
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
SQL
ok "База данных '${DB_NAME}' и пользователь '${DB_USER}' настроены"

# ── 5. PM2 ────────────────────────────────────────────────────────────────────
if ! command -v pm2 &>/dev/null; then
  info "Установка PM2..."
  npm install -g pm2 --quiet
  ok "PM2 установлен"
fi

# ── 6. Копирование файлов приложения ─────────────────────────────────────────
info "Развёртывание файлов приложения в ${APP_DIR}..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "${APP_DIR}"
cp -r "${SCRIPT_DIR}/backend"  "${APP_DIR}/"
cp -r "${SCRIPT_DIR}/frontend" "${APP_DIR}/"

# ── 7. Backend .env ───────────────────────────────────────────────────────────
info "Создание конфигурации backend..."
cat > "${APP_DIR}/backend/.env" <<ENV
DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}"
JWT_SECRET="${JWT_SECRET}"
PORT=${BACKEND_PORT}
FRONTEND_URL="http://${DOMAIN}"
NODE_ENV=production
ENV
ok ".env создан"

# ── 8. Backend: зависимости и миграции ───────────────────────────────────────
info "Установка зависимостей backend..."
cd "${APP_DIR}/backend"
npm install --quiet
ok "npm install завершён"

info "Генерация Prisma client..."
npx prisma generate --schema=./prisma/schema.prisma
ok "Prisma client сгенерирован"

info "Применение миграций базы данных..."
DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}" \
  npx prisma migrate deploy --schema=./prisma/schema.prisma
ok "Миграции применены"

info "Загрузка демо-данных..."
DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}" \
  npx tsx prisma/seed.ts && ok "Демо-данные загружены" || info "Демо-данные уже существуют, пропущено"

# ── 9. Frontend: сборка ───────────────────────────────────────────────────────
info "Сборка frontend..."
cd "${APP_DIR}/frontend"
npm install --quiet
npm run build
ok "Frontend собран в dist/"

# ── 10. PM2: запуск backend ───────────────────────────────────────────────────
info "Запуск backend через PM2..."
cd "${APP_DIR}/backend"
pm2 delete edusystem-backend 2>/dev/null || true
pm2 start "npx tsx src/index.ts" \
  --name "edusystem-backend" \
  --env production \
  --log "${APP_DIR}/logs/backend.log" \
  --time
pm2 save
pm2 startup systemd -u root --hp /root | tail -1 | bash || true
ok "Backend запущен (PM2)"

# ── 11. Nginx ─────────────────────────────────────────────────────────────────
info "Настройка Nginx..."
mkdir -p "${APP_DIR}/logs"
cat > /etc/nginx/sites-available/edusystem <<NGINX
server {
    listen 80;
    server_name ${DOMAIN};

    # Frontend (статика Vue)
    root ${APP_DIR}/frontend/dist;
    index index.html;

    location / {
        try_files \$uri \$uri/ /index.html;
        add_header Cache-Control "no-cache";
    }

    # Статические ассеты — длинный кэш
    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Backend API proxy
    location /api/ {
        proxy_pass         http://127.0.0.1:${BACKEND_PORT};
        proxy_http_version 1.1;
        proxy_set_header   Upgrade \$http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host \$host;
        proxy_set_header   X-Real-IP \$remote_addr;
        proxy_set_header   X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 120s;
    }

    # Логи
    access_log ${APP_DIR}/logs/nginx-access.log;
    error_log  ${APP_DIR}/logs/nginx-error.log;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
}
NGINX

ln -sf /etc/nginx/sites-available/edusystem /etc/nginx/sites-enabled/edusystem
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
ok "Nginx настроен и перезагружен"

# ── Финальный отчёт ───────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║          ✅  EduSystem успешно установлен!           ║"
echo "╠══════════════════════════════════════════════════════╣"
printf "║  URL:      http://%-35s║\n" "${DOMAIN}"
printf "║  API:      http://${DOMAIN}/api/health%-17s║\n" " "
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Демо-аккаунты:                                      ║"
echo "║    admin@school.kz    / admin123   (Администратор)   ║"
echo "║    teacher@school.kz  / teacher123 (Преподаватель)   ║"
echo "║    student@school.kz  / student123 (Студент)         ║"
echo "╠══════════════════════════════════════════════════════╣"
printf "║  DB пользователь: %-34s║\n" "${DB_USER}"
printf "║  DB пароль:       %-34s║\n" "${DB_PASS}"
printf "║  JWT Secret сохранён в: %-29s║\n" "${APP_DIR}/backend/.env"
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Управление:                                         ║"
echo "║    pm2 status                — статус процессов      ║"
echo "║    pm2 logs edusystem-backend — логи backend         ║"
echo "║    pm2 restart edusystem-backend — перезапуск        ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "⚡ Для HTTPS: sudo certbot --nginx -d ${DOMAIN}"
echo ""
