import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '../stores/auth'
const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', component: () => import('../views/LoginView.vue'), meta: { public: true } },
    { path: '/', component: () => import('../components/AppLayout.vue'), children: [
      { path: '',                     redirect: '/dashboard' },
      { path: 'dashboard',            component: () => import('../views/DashboardView.vue') },
      { path: 'diary',                component: () => import('../views/DiaryView.vue') },
      { path: 'schedule',             component: () => import('../views/ScheduleView.vue') },
      { path: 'admin/users',          component: () => import('../views/admin/UsersView.vue'),      meta: { roles: ['ADMIN'] } },
      { path: 'admin/workload',       component: () => import('../views/admin/WorkloadView.vue'),   meta: { roles: ['ADMIN'] } },
      { path: 'teacher/grades',       component: () => import('../views/teacher/GradesView.vue'),   meta: { roles: ['TEACHER','ADMIN'] } },
      { path: 'teacher/assignments',  component: () => import('../views/teacher/AssignmentsView.vue'), meta: { roles: ['TEACHER','ADMIN'] } },
    ]},
    { path: '/:pathMatch(.*)*', redirect: '/' },
  ],
})
router.beforeEach((to) => {
  const auth = useAuthStore()
  if (!to.meta.public && !auth.isLoggedIn) return '/login'
  if (to.meta.public && auth.isLoggedIn) return '/dashboard'
  const roles = to.meta.roles as string[] | undefined
  if (roles && auth.user && !roles.includes(auth.user.role)) return '/dashboard'
})
export default router
