<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import AppIcon from '../components/AppIcon.vue'

const auth     = useAuthStore()
const router   = useRouter()
const email    = ref('')
const password = ref('')
const error    = ref('')
const loading  = ref(false)

const demos = [
  { label: 'Администратор', email: 'admin@school.kz',   password: 'admin123',   color: 'bg-red-500/20 text-red-300 hover:bg-red-500/30' },
  { label: 'Преподаватель', email: 'teacher@school.kz', password: 'teacher123', color: 'bg-blue-500/20 text-blue-300 hover:bg-blue-500/30' },
  { label: 'Студент',       email: 'student@school.kz', password: 'student123', color: 'bg-green-500/20 text-green-300 hover:bg-green-500/30' },
]

function fillDemo(d: typeof demos[0]) { email.value = d.email; password.value = d.password }

async function submit() {
  if (!email.value || !password.value) { error.value = 'Заполните все поля'; return }
  loading.value = true; error.value = ''
  try {
    await auth.signIn(email.value, password.value)
    router.push('/dashboard')
  } catch {
    error.value = 'Неверный email или пароль'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="min-h-screen bg-slate-900 flex items-center justify-center p-4">
    <!-- Background decoration -->
    <div class="absolute inset-0 overflow-hidden pointer-events-none">
      <div class="absolute -top-40 -right-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
      <div class="absolute -bottom-40 -left-40 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl"></div>
    </div>

    <div class="w-full max-w-md relative">
      <!-- Header -->
      <div class="text-center mb-8">
        <div class="inline-flex w-16 h-16 bg-blue-600 rounded-2xl items-center justify-center mb-4 shadow-lg shadow-blue-600/30">
          <AppIcon name="graduate" class="w-8 h-8 text-white" />
        </div>
        <h1 class="text-3xl font-bold text-white tracking-tight">EduSystem</h1>
        <p class="text-slate-400 mt-2 text-sm">Образовательная среда</p>
      </div>

      <!-- Card -->
      <div class="bg-slate-800 rounded-2xl shadow-2xl border border-slate-700/50 p-8">
        <h2 class="text-lg font-semibold text-white mb-6">Вход в систему</h2>

        <form @submit.prevent="submit" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-1.5">Email</label>
            <input v-model="email" type="email" autocomplete="username"
              class="block w-full rounded-lg border border-slate-600 bg-slate-700/50 px-3 py-2.5 text-white placeholder-slate-400 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition"
              placeholder="your@school.kz" />
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-1.5">Пароль</label>
            <input v-model="password" type="password" autocomplete="current-password"
              class="block w-full rounded-lg border border-slate-600 bg-slate-700/50 px-3 py-2.5 text-white placeholder-slate-400 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition"
              placeholder="••••••••" />
          </div>

          <div v-if="error" class="flex items-center gap-2 text-sm text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2.5">
            <AppIcon name="warning" class="w-4 h-4 flex-shrink-0" />
            {{ error }}
          </div>

          <button type="submit"
            class="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 px-4 rounded-lg transition-colors duration-150 text-sm mt-2"
            :disabled="loading">
            <AppIcon v-if="loading" name="refresh" class="w-4 h-4 animate-spin" />
            <AppIcon v-else name="arrow-right" class="w-4 h-4" />
            {{ loading ? 'Вход...' : 'Войти' }}
          </button>
        </form>

        <!-- Demo accounts -->
        <div class="mt-6 pt-6 border-t border-slate-700">
          <p class="text-xs text-slate-500 mb-3 text-center uppercase tracking-wider">Демо-аккаунты</p>
          <div class="flex gap-2 flex-wrap justify-center">
            <button v-for="d in demos" :key="d.email"
              @click="fillDemo(d)"
              :class="['text-xs px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer', d.color]">
              {{ d.label }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
