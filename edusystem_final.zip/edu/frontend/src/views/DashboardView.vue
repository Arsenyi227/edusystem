<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useAuthStore } from '../stores/auth'
import { adminApi, teacherApi, studentApi, scheduleApi } from '../api'
import AppIcon from '../components/AppIcon.vue'

const auth    = useAuthStore()
const stats   = ref<any>(null)
const diary   = ref<any>(null)
const mySubjects = ref<any[]>([])
const schedule   = ref<any[]>([])
const loading    = ref(true)

const TIMES = ['', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00']
const today = new Date().getDay()
const todayNum = today === 0 ? 1 : today === 6 ? 5 : today

const todayLessons = computed(() =>
  schedule.value.filter(e => e.dayOfWeek === todayNum)
)
const gradeColor = (v: number) =>
  v >= 5 ? 'badge-green' : v >= 4 ? 'badge-blue' : v >= 3 ? 'badge-amber' : 'badge-red'

const statCards = computed(() => !stats.value ? [] : [
  { label: 'Студентов',      value: stats.value.students, icon: 'student',  bg: 'bg-blue-50',   text: 'text-blue-600' },
  { label: 'Преподавателей', value: stats.value.teachers, icon: 'teacher',  bg: 'bg-green-50',  text: 'text-green-600' },
  { label: 'Групп',          value: stats.value.groups,   icon: 'group',    bg: 'bg-purple-50', text: 'text-purple-600' },
  { label: 'Предметов',      value: stats.value.subjects, icon: 'subject',  bg: 'bg-amber-50',  text: 'text-amber-600' },
])

onMounted(async () => {
  try {
    if (auth.isAdmin) {
      stats.value = (await adminApi.getStats()).data
    }
    if (auth.isTeacher) {
      const [s, sch] = await Promise.all([teacherApi.getMySubjects(), scheduleApi.getMine()])
      mySubjects.value = s.data
      schedule.value   = sch.data
    }
    if (auth.isStudent) {
      const [d, sch] = await Promise.all([studentApi.getDiary(), scheduleApi.getStudent()])
      diary.value    = d.data
      schedule.value = sch.data
    }
  } finally { loading.value = false }
})
</script>

<template>
  <div class="p-8">
    <!-- Header -->
    <div class="mb-8">
      <h1 class="text-2xl font-bold text-slate-900">
        Добро пожаловать, {{ auth.user?.name.split(' ')[0] }}
      </h1>
      <p class="text-slate-500 mt-1 text-sm">
        {{ new Date().toLocaleDateString('ru-RU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) }}
      </p>
    </div>

    <div v-if="loading" class="flex items-center gap-3 text-slate-400">
      <AppIcon name="refresh" class="w-5 h-5 animate-spin" /> Загрузка...
    </div>

    <!-- ADMIN -->
    <template v-if="auth.isAdmin && stats">
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div v-for="c in statCards" :key="c.label" class="card flex items-center gap-4">
          <div :class="['w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0', c.bg]">
            <AppIcon :name="c.icon" :class="'w-6 h-6 ' + c.text" />
          </div>
          <div>
            <div class="text-2xl font-bold text-slate-900">{{ c.value }}</div>
            <div class="text-sm text-slate-500">{{ c.label }}</div>
          </div>
        </div>
      </div>
      <div class="card">
        <h3 class="font-semibold text-slate-800 mb-4 flex items-center gap-2">
          <AppIcon name="lightning" class="w-5 h-5 text-amber-500" /> Быстрые действия
        </h3>
        <div class="flex flex-wrap gap-3">
          <RouterLink to="/admin/users" class="btn-primary">
            <AppIcon name="users" class="w-4 h-4" /> Пользователи
          </RouterLink>
          <RouterLink to="/schedule" class="btn-secondary">
            <AppIcon name="calendar" class="w-4 h-4" /> Расписание
          </RouterLink>
          <RouterLink to="/teacher/subjects" class="btn-secondary">
            <AppIcon name="book-stack" class="w-4 h-4" /> Предметы
          </RouterLink>
        </div>
      </div>
    </template>

    <!-- TEACHER -->
    <template v-if="auth.isTeacher">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="card">
          <h3 class="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <AppIcon name="calendar" class="w-5 h-5 text-blue-500" /> Занятия сегодня
          </h3>
          <div v-if="!todayLessons.length" class="text-slate-400 text-sm py-6 text-center">
            Нет занятий сегодня
          </div>
          <div v-for="e in todayLessons" :key="e.id"
            class="flex items-center gap-3 py-3 border-b border-slate-100 last:border-0">
            <div class="w-14 h-10 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
              <span class="text-xs font-bold text-blue-700">{{ TIMES[e.lessonNum - 1] }}</span>
            </div>
            <div>
              <div class="font-medium text-sm text-slate-800">{{ e.subject.name }}</div>
              <div class="text-xs text-slate-500">Группа {{ e.group.name }}</div>
            </div>
          </div>
        </div>
        <div class="card">
          <h3 class="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <AppIcon name="book-stack" class="w-5 h-5 text-purple-500" /> Мои предметы
          </h3>
          <div v-if="!mySubjects.length" class="text-slate-400 text-sm py-6 text-center">Предметы не назначены</div>
          <div v-for="s in mySubjects" :key="s.id"
            class="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
            <div>
              <div class="font-medium text-sm text-slate-800">{{ s.subject.name }}</div>
              <div class="text-xs text-slate-500">Группа {{ s.group.name }}</div>
            </div>
            <span class="badge-blue badge">{{ s.hoursPerWeek }} ч/нед</span>
          </div>
        </div>
      </div>
    </template>

    <!-- STUDENT -->
    <template v-if="auth.isStudent && diary">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="card">
          <h3 class="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <AppIcon name="calendar" class="w-5 h-5 text-blue-500" /> Расписание сегодня
          </h3>
          <div v-if="!todayLessons.length" class="text-slate-400 text-sm py-6 text-center">Нет занятий</div>
          <div v-for="e in todayLessons" :key="e.id"
            class="flex items-center gap-3 py-3 border-b border-slate-100 last:border-0">
            <div class="w-14 h-8 bg-blue-50 rounded flex items-center justify-center flex-shrink-0">
              <span class="text-xs font-bold text-blue-700">{{ TIMES[e.lessonNum - 1] }}</span>
            </div>
            <div>
              <div class="font-medium text-sm text-slate-800">{{ e.subject.name }}</div>
              <div class="text-xs text-slate-500">{{ e.teacher.user.name }}</div>
            </div>
          </div>
        </div>
        <div class="card">
          <h3 class="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <AppIcon name="pencil" class="w-5 h-5 text-green-500" /> Последние оценки
          </h3>
          <div v-if="!diary.grades?.length" class="text-slate-400 text-sm py-6 text-center">Оценок пока нет</div>
          <div v-for="g in diary.grades?.slice(0, 6)" :key="g.id"
            class="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
            <div>
              <div class="font-medium text-sm text-slate-800">{{ g.subject.name }}</div>
              <div class="text-xs text-slate-500">{{ new Date(g.date).toLocaleDateString('ru-RU') }}</div>
            </div>
            <span :class="['badge text-base font-bold px-3 py-1', gradeColor(g.value)]">{{ g.value }}</span>
          </div>
        </div>

        <div class="card lg:col-span-2">
          <h3 class="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <AppIcon name="clipboard" class="w-5 h-5 text-orange-500" /> Ближайшие задания
          </h3>
          <div v-if="!diary.assignments?.length" class="text-slate-400 text-sm py-6 text-center">Заданий нет</div>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            <div v-for="a in diary.assignments?.slice(0, 6)" :key="a.id"
              class="border border-slate-200 rounded-xl p-4 hover:border-slate-300 transition-colors">
              <div class="flex items-start justify-between gap-2 mb-2">
                <span class="badge-blue badge">{{ a.subject.name }}</span>
                <span class="text-xs text-slate-500 whitespace-nowrap">
                  {{ new Date(a.dueDate).toLocaleDateString('ru-RU') }}
                </span>
              </div>
              <div class="font-medium text-sm text-slate-800 mt-2">{{ a.title }}</div>
              <div v-if="a.description" class="text-xs text-slate-500 mt-1 line-clamp-2">{{ a.description }}</div>
            </div>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>
