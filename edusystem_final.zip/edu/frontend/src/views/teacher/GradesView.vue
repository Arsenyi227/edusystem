<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { teacherApi, adminApi } from '../../api'
import { useAuthStore } from '../../stores/auth'
import AppIcon from '../../components/AppIcon.vue'

const auth        = useAuthStore()
const mySubjects = ref<any[]>([])
const grades     = ref<any[]>([])
const selTSG     = ref<any>(null)
const loading    = ref(true)
const showModal  = ref(false)
const form       = ref({ studentId: '', value: '5', comment: '' })
const saving     = ref(false)
const formErr    = ref('')

const gradeColor = (v: number) =>
  v >= 5 ? 'badge-green' : v >= 4 ? 'badge-blue' : v >= 3 ? 'badge-amber' : 'badge-red'

const students = computed(() => selTSG.value?.group?.students || [])
const byStudent = computed(() => {
  const map = new Map<number, { student: any; grades: any[] }>()
  for (const s of students.value) map.set(s.id, { student: s, grades: [] })
  for (const g of grades.value) {
    if (map.has(g.student.id)) map.get(g.student.id)!.grades.push(g)
  }
  return [...map.values()]
})
const avg = (gs: any[]) => gs.length ? (gs.reduce((s, g) => s + g.value, 0) / gs.length).toFixed(1) : '—'

async function selectTSG(tsg: any) {
  selTSG.value = tsg
  grades.value = (await teacherApi.getGrades({ subjectId: tsg.subjectId, groupId: tsg.groupId })).data
}

async function addGrade() {
  if (!form.value.studentId || !form.value.value) { formErr.value = 'Заполните поля'; return }
  saving.value = true; formErr.value = ''
  try {
    const r = await teacherApi.addGrade({
      studentId: Number(form.value.studentId),
      subjectId: selTSG.value.subjectId,
      value: Number(form.value.value),
      comment: form.value.comment,
    })
    grades.value.unshift(r.data)
    form.value = { studentId: '', value: '5', comment: '' }
    showModal.value = false
  } catch (e: any) { formErr.value = e.response?.data?.error || 'Ошибка' }
  finally { saving.value = false }
}

async function del(id: number) {
  if (!confirm('Удалить оценку?')) return
  await teacherApi.deleteGrade(id)
  grades.value = grades.value.filter(g => g.id !== id)
}

onMounted(async () => {
  mySubjects.value = auth.isAdmin
    ? (await adminApi.getWorkload()).data
    : (await teacherApi.getMySubjects()).data
  if (mySubjects.value.length) await selectTSG(mySubjects.value[0])
  loading.value = false
})
</script>

<template>
  <div class="p-8">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-4">
      <div>
        <h1 class="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <AppIcon name="pencil" class="w-7 h-7 text-green-500" /> Оценки
        </h1>
        <p class="text-slate-500 text-sm mt-1">Выставление и управление оценками</p>
      </div>
      <button v-if="selTSG" @click="showModal = true; formErr = ''" class="btn-primary">
        <AppIcon name="plus" class="w-4 h-4" /> Выставить оценку
      </button>
    </div>

    <div v-if="loading" class="text-slate-500 flex items-center gap-2 py-8">
      <AppIcon name="refresh" class="w-5 h-5 animate-spin" /> Загрузка...
    </div>

    <div v-else class="flex gap-6">
      <!-- Sidebar -->
      <div class="w-52 flex-shrink-0">
        <div class="card p-3 space-y-1">
          <p class="text-xs font-semibold text-slate-500 px-2 pb-2 uppercase tracking-wide">Предмет / Группа</p>
          <button v-for="tsg in mySubjects" :key="tsg.id" @click="selectTSG(tsg)"
            :class="['w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors',
              selTSG?.id === tsg.id ? 'bg-blue-600 text-white' : 'hover:bg-slate-100 text-slate-700']">
            <div class="font-medium">{{ tsg.subject.name }}</div>
            <div :class="['text-xs', selTSG?.id === tsg.id ? 'text-blue-200' : 'text-slate-400']">
              Гр. {{ tsg.group.name }}
            </div>
          </button>
          <div v-if="!mySubjects.length" class="text-xs text-slate-400 px-2 py-3 text-center">Нет предметов</div>
        </div>
      </div>

      <!-- Table -->
      <div class="flex-1">
        <div v-if="!selTSG" class="card text-center text-slate-400 py-12">Выберите предмет</div>
        <div v-else class="card p-0 overflow-hidden">
          <div class="px-6 py-4 border-b border-slate-200 bg-slate-50">
            <h3 class="font-semibold text-slate-800">
              {{ selTSG.subject.name }} — Группа {{ selTSG.group.name }}
            </h3>
          </div>
          <table class="w-full">
            <thead>
              <tr class="border-b border-slate-200">
                <th class="th">Студент</th>
                <th class="th text-center">Средний балл</th>
                <th class="th">Оценки</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="row in byStudent" :key="row.student.id" class="table-row align-top">
                <td class="td font-medium whitespace-nowrap">{{ row.student.user.name }}</td>
                <td class="td text-center">
                  <span v-if="row.grades.length"
                    :class="['badge font-bold text-base', gradeColor(Number(avg(row.grades)))]">
                    {{ avg(row.grades) }}
                  </span>
                  <span v-else class="text-slate-400 text-sm">—</span>
                </td>
                <td class="td">
                  <div class="flex flex-wrap gap-2 items-center py-1">
                    <div v-for="g in row.grades" :key="g.id" class="group relative flex items-center">
                      <span :class="['badge font-bold px-2.5 py-1', gradeColor(g.value)]">{{ g.value }}</span>
                      <button @click="del(g.id)"
                        class="absolute -top-1 -right-1 w-4 h-4 bg-slate-700 text-white rounded-full hidden group-hover:flex items-center justify-center">
                        <AppIcon name="x-mark" class="w-2.5 h-2.5" />
                      </button>
                      <div class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-slate-800 text-white text-xs rounded px-2 py-1 whitespace-nowrap z-10 pointer-events-none">
                        {{ new Date(g.date).toLocaleDateString('ru-RU') }}
                        <span v-if="g.comment"> · {{ g.comment }}</span>
                      </div>
                    </div>
                    <span v-if="!row.grades.length" class="text-slate-400 text-sm">—</span>
                  </div>
                </td>
              </tr>
              <tr v-if="!byStudent.length">
                <td colspan="3" class="td text-center text-slate-400 py-8">Нет студентов</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div v-if="showModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div class="bg-white rounded-2xl shadow-2xl w-full max-w-sm">
        <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 class="font-semibold flex items-center gap-2">
            <AppIcon name="pencil" class="w-5 h-5 text-green-500" /> Выставить оценку
          </h2>
          <button @click="showModal = false" class="text-slate-400 hover:text-slate-600 rounded-lg p-1 hover:bg-slate-100">
            <AppIcon name="x-mark" class="w-5 h-5" />
          </button>
        </div>
        <div class="p-6 space-y-4">
          <div>
            <label class="label">Студент *</label>
            <select v-model="form.studentId" class="input">
              <option value="">— Выберите студента —</option>
              <option v-for="s in students" :key="s.id" :value="s.id">{{ s.user.name }}</option>
            </select>
          </div>
          <div>
            <label class="label">Оценка *</label>
            <div class="flex gap-2">
              <button v-for="n in [1,2,3,4,5]" :key="n" @click="form.value = String(n)"
                :class="['w-12 h-12 rounded-xl font-bold text-lg transition-all border',
                  form.value == String(n)
                    ? 'bg-blue-600 text-white border-blue-600 scale-110 shadow-md'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300']">
                {{ n }}
              </button>
            </div>
          </div>
          <div>
            <label class="label">Комментарий</label>
            <input v-model="form.comment" class="input" placeholder="Необязательно..." />
          </div>
          <div v-if="formErr" class="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2 flex items-center gap-2">
            <AppIcon name="warning" class="w-4 h-4 flex-shrink-0" /> {{ formErr }}
          </div>
        </div>
        <div class="px-6 py-4 border-t border-slate-200 flex justify-end gap-3">
          <button @click="showModal = false" class="btn-secondary">Отмена</button>
          <button @click="addGrade" :disabled="saving" class="btn-primary">
            <AppIcon :name="saving ? 'refresh' : 'check'" :class="'w-4 h-4' + (saving ? ' animate-spin' : '')" />
            {{ saving ? 'Сохранение...' : 'Выставить' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
