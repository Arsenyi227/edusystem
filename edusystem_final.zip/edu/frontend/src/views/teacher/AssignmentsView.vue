<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { teacherApi } from '../../api'
import AppIcon from '../../components/AppIcon.vue'

const assignments = ref<any[]>([])
const formData    = ref<any>({ groups: [], subjects: [] })
const loading     = ref(true)
const showModal   = ref(false)
const saving      = ref(false)
const formErr     = ref('')
const form        = ref({ subjectId: '', groupId: '', title: '', description: '', dueDate: '' })

const isOverdue = (d: string) => new Date(d) < new Date()

async function load() {
  const [a, fd] = await Promise.all([teacherApi.getAssignments(), teacherApi.getFormData()])
  assignments.value = a.data; formData.value = fd.data
}

async function create() {
  if (!form.value.title || !form.value.subjectId || !form.value.groupId || !form.value.dueDate) {
    formErr.value = 'Заполните все обязательные поля'; return
  }
  saving.value = true; formErr.value = ''
  try {
    await teacherApi.addAssignment({
      subjectId: Number(form.value.subjectId), groupId: Number(form.value.groupId),
      title: form.value.title, description: form.value.description, dueDate: form.value.dueDate,
    })
    await load(); showModal.value = false
    form.value = { subjectId: '', groupId: '', title: '', description: '', dueDate: '' }
  } catch (e: any) { formErr.value = e.response?.data?.error || 'Ошибка' }
  finally { saving.value = false }
}

async function del(id: number, title: string) {
  if (!confirm(`Удалить задание «${title}»?`)) return
  await teacherApi.deleteAssignment(id)
  assignments.value = assignments.value.filter(a => a.id !== id)
}

onMounted(async () => { await load(); loading.value = false })
</script>

<template>
  <div class="p-8">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-4">
      <div>
        <h1 class="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <AppIcon name="clipboard" class="w-7 h-7 text-orange-500" /> Задания
        </h1>
        <p class="text-slate-500 text-sm mt-1">{{ assignments.length }} заданий</p>
      </div>
      <button @click="showModal = true; formErr = ''" class="btn-primary">
        <AppIcon name="plus" class="w-4 h-4" /> Новое задание
      </button>
    </div>

    <div v-if="loading" class="text-slate-500 flex items-center gap-2 py-8">
      <AppIcon name="refresh" class="w-5 h-5 animate-spin" /> Загрузка...
    </div>

    <div v-else class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
      <div v-for="a in assignments" :key="a.id"
        :class="['card hover:shadow-md transition-shadow relative', isOverdue(a.dueDate) ? 'border-red-200' : '']">
        <div v-if="isOverdue(a.dueDate)" class="absolute top-3 right-3">
          <span class="badge bg-red-100 text-red-700 text-xs flex items-center gap-1">
            <AppIcon name="warning" class="w-3 h-3" /> Просрочено
          </span>
        </div>
        <div class="flex gap-2 flex-wrap mb-3 pr-20">
          <span class="badge-blue badge">{{ a.subject.name }}</span>
          <span class="badge bg-slate-100 text-slate-600">Гр. {{ a.group.name }}</span>
        </div>
        <h3 class="font-semibold text-slate-900 mb-1">{{ a.title }}</h3>
        <p v-if="a.description" class="text-sm text-slate-500 mb-3 line-clamp-3">{{ a.description }}</p>
        <div class="flex items-center justify-between mt-auto pt-3 border-t border-slate-100">
          <div class="text-xs text-slate-500 flex items-center gap-1">
            <AppIcon name="clock" class="w-3.5 h-3.5" />
            <span :class="isOverdue(a.dueDate) ? 'text-red-600 font-semibold' : ''">
              {{ new Date(a.dueDate).toLocaleDateString('ru-RU') }}
            </span>
          </div>
          <button @click="del(a.id, a.title)"
            class="flex items-center gap-1 text-slate-400 hover:text-red-500 transition-colors text-xs">
            <AppIcon name="trash" class="w-4 h-4" /> Удалить
          </button>
        </div>
      </div>

      <div v-if="!assignments.length"
        class="md:col-span-2 xl:col-span-3 card text-center py-12 text-slate-400 border-dashed">
        <AppIcon name="clipboard" class="w-12 h-12 mx-auto mb-3 opacity-40" />
        <p class="font-medium">Заданий пока нет</p>
        <p class="text-sm mt-1">Нажмите «Новое задание», чтобы создать первое</p>
      </div>
    </div>

    <!-- Modal -->
    <div v-if="showModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 class="font-semibold flex items-center gap-2">
            <AppIcon name="clipboard" class="w-5 h-5 text-orange-500" /> Новое задание
          </h2>
          <button @click="showModal = false" class="text-slate-400 hover:text-slate-600 rounded-lg p-1 hover:bg-slate-100">
            <AppIcon name="x-mark" class="w-5 h-5" />
          </button>
        </div>
        <div class="p-6 space-y-4">
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="label">Предмет *</label>
              <select v-model="form.subjectId" class="input">
                <option value="">— Выбрать —</option>
                <option v-for="s in formData.subjects" :key="s.id" :value="s.id">{{ s.name }}</option>
              </select>
            </div>
            <div>
              <label class="label">Группа *</label>
              <select v-model="form.groupId" class="input">
                <option value="">— Выбрать —</option>
                <option v-for="g in formData.groups" :key="g.id" :value="g.id">{{ g.name }}</option>
              </select>
            </div>
          </div>
          <div>
            <label class="label">Название *</label>
            <input v-model="form.title" class="input" placeholder="Домашнее задание по теме..." />
          </div>
          <div>
            <label class="label">Описание</label>
            <textarea v-model="form.description" class="input min-h-[80px] resize-none"
              placeholder="Подробное описание задания..." />
          </div>
          <div>
            <label class="label">Срок сдачи *</label>
            <input v-model="form.dueDate" type="datetime-local" class="input" />
          </div>
          <div v-if="formErr" class="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2 flex items-center gap-2">
            <AppIcon name="warning" class="w-4 h-4 flex-shrink-0" /> {{ formErr }}
          </div>
        </div>
        <div class="px-6 py-4 border-t border-slate-200 flex justify-end gap-3">
          <button @click="showModal = false" class="btn-secondary">Отмена</button>
          <button @click="create" :disabled="saving" class="btn-primary">
            <AppIcon :name="saving ? 'refresh' : 'check'" :class="'w-4 h-4' + (saving ? ' animate-spin' : '')" />
            {{ saving ? 'Создание...' : 'Создать' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
