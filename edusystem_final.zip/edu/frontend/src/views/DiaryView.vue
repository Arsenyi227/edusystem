<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useAuthStore } from '../stores/auth'
import { studentApi, teacherApi, adminApi } from '../api'
import GradeInput from '../components/GradeInput.vue'
import AppIcon from '../components/AppIcon.vue'

const auth    = useAuthStore()
const loading = ref(true)

// Student data
const diary = ref<any>(null)

// Teacher data
const mySubjects  = ref<any[]>([])
const selSubject  = ref<any>(null)
const grades      = ref<any[]>([])
const activeTab   = ref<'grades' | 'attendance'>('grades')

const gradeColor = (v: number) =>
  v >= 5 ? 'badge-green' : v >= 4 ? 'badge-blue' : v >= 3 ? 'badge-amber' : 'badge-red'

// ── Student ──────────────────────────────────────────────────────────────────
const bySubject = computed(() => {
  if (!diary.value?.grades) return []
  const map = new Map<number, { subject: any; grades: any[] }>()
  for (const g of diary.value.grades) {
    if (!map.has(g.subjectId)) map.set(g.subjectId, { subject: g.subject, grades: [] })
    map.get(g.subjectId)!.grades.push(g)
  }
  return [...map.values()]
})

const avg = (gs: any[]) =>
  gs.length ? (gs.reduce((s, g) => s + g.value, 0) / gs.length).toFixed(1) : '-'

// ── Teacher ──────────────────────────────────────────────────────────────────
async function loadGrades() {
  if (!selSubject.value) return
  const r = await teacherApi.getGrades({
    subjectId: selSubject.value.subjectId,
    groupId:   selSubject.value.groupId,
  })
  grades.value = r.data
}

async function selectSubject(s: any) {
  selSubject.value = s
  await loadGrades()
}

async function deleteGrade(id: number) {
  await teacherApi.deleteGrade(id)
  grades.value = grades.value.filter(g => g.id !== id)
}

// Attendance
const attendanceDate     = ref(new Date().toISOString().split('T')[0])
const lessonNum          = ref(1)
const attendanceStudents = ref<any[]>([])

async function loadAttendance() {
  if (!selSubject.value) return
  const r = await teacherApi.getAttendance({
    groupId: selSubject.value.groupId,
    date:    attendanceDate.value,
  })
  if (selSubject.value?.group?.students) {
    attendanceStudents.value = selSubject.value.group.students.map((s: any) => {
      const rec = r.data.find((a: any) => a.studentId === s.id && a.lessonNum === lessonNum.value)
      return { ...s, present: rec ? rec.present : true }
    })
  }
}

async function saveAttendance() {
  const data = attendanceStudents.value.map(s => ({
    studentId: s.id,
    date:      attendanceDate.value,
    lessonNum: lessonNum.value,
    present:   s.present,
  }))
  await teacherApi.saveAttendance(data)
  alert('Посещаемость сохранена')
}

onMounted(async () => {
  try {
    if (auth.isStudent) {
      diary.value = (await studentApi.getDiary()).data
    }
    if (auth.isTeacher || auth.isAdmin) {
      mySubjects.value = auth.isAdmin
        ? (await adminApi.getWorkload()).data
        : (await teacherApi.getMySubjects()).data
      if (mySubjects.value.length) await selectSubject(mySubjects.value[0])
    }
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div class="p-8">
    <h1 class="text-2xl font-bold text-slate-900 mb-6">Дневник</h1>

    <div v-if="loading" class="text-slate-500 flex items-center gap-2"><AppIcon name="refresh" class="w-5 h-5 animate-spin" /> Загрузка...</div>

    <!-- ─── STUDENT view ──────────────────────────────────────────────────── -->
    <template v-else-if="auth.isStudent && diary">
      <div class="mb-4">
        <span class="text-slate-600 text-sm">Группа: <strong>{{ diary.student.group.name }}</strong></span>
      </div>

      <div class="grid gap-4 mb-8">
        <div v-if="!bySubject.length" class="card text-center text-slate-400 py-8">Оценок пока нет</div>
        <div v-for="s in bySubject" :key="s.subject.id" class="card">
          <div class="flex items-center justify-between mb-3">
            <h3 class="font-semibold text-slate-800">{{ s.subject.name }}</h3>
            <div class="flex items-center gap-2">
              <span class="text-xs text-slate-500">Средний балл:</span>
              <span :class="['badge font-bold text-sm', gradeColor(Number(avg(s.grades)))]">{{ avg(s.grades) }}</span>
            </div>
          </div>
          <div class="flex flex-wrap gap-2">
            <div v-for="g in s.grades" :key="g.id" class="group relative">
              <span :class="['badge text-base font-bold px-3 py-1.5 cursor-default', gradeColor(g.value)]">
                {{ g.value }}
              </span>
              <div class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-slate-800 text-white text-xs rounded px-2 py-1 whitespace-nowrap z-10">
                {{ new Date(g.date).toLocaleDateString('ru-RU') }}<span v-if="g.comment"> · {{ g.comment }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <h2 class="text-lg font-semibold text-slate-800 mb-4">Задания</h2>
      <div v-if="!diary.assignments?.length" class="card text-center text-slate-400 py-8">Заданий нет</div>
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <div v-for="a in diary.assignments" :key="a.id" class="card hover:shadow-md transition-shadow">
          <div class="flex items-start justify-between gap-2 mb-2">
            <span class="badge-blue badge">{{ a.subject.name }}</span>
            <span :class="['text-xs font-medium', new Date(a.dueDate) < new Date() ? 'text-red-500' : 'text-slate-500']">
              до {{ new Date(a.dueDate).toLocaleDateString('ru-RU') }}
            </span>
          </div>
          <h4 class="font-semibold text-slate-800 mt-2">{{ a.title }}</h4>
          <p v-if="a.description" class="text-sm text-slate-500 mt-1">{{ a.description }}</p>
          <p class="text-xs text-slate-400 mt-2">{{ a.teacher.user.name }}</p>
        </div>
      </div>
    </template>

    <!-- ─── TEACHER view ──────────────────────────────────────────────────── -->
    <template v-else-if="auth.isTeacher || auth.isAdmin">
      <div class="flex gap-6">
        <div class="w-56 flex-shrink-0">
          <div class="card p-3 space-y-1">
            <p class="text-xs font-semibold text-slate-500 px-2 pb-2 uppercase tracking-wide">Предмет / Группа</p>
            <button v-for="s in mySubjects" :key="s.id"
              @click="selectSubject(s)"
              :class="['w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors',
                selSubject?.id === s.id ? 'bg-blue-600 text-white' : 'hover:bg-slate-100 text-slate-700']"
            >
              <div class="font-medium">{{ s.subject.name }}</div>
              <div :class="['text-xs', selSubject?.id === s.id ? 'text-blue-200' : 'text-slate-400']">
                Гр. {{ s.group.name }}
              </div>
            </button>
            <div v-if="!mySubjects.length" class="text-xs text-slate-400 px-2 py-3 text-center">
              Нет предметов. Добавьте в разделе «Предметы / Группы»
            </div>
          </div>
        </div>

        <div class="flex-1">
          <div v-if="!selSubject" class="card text-center text-slate-400 py-12">Выберите предмет</div>
          <template v-else>
            <div class="flex gap-2 mb-4">
              <button @click="activeTab = 'grades'"
                :class="['btn', activeTab === 'grades' ? 'btn-primary' : 'btn-secondary']"><AppIcon name="pencil" class="w-4 h-4" /> Оценки</button>
              <button @click="activeTab = 'attendance'; loadAttendance()"
                :class="['btn', activeTab === 'attendance' ? 'btn-primary' : 'btn-secondary']">📊 Посещаемость</button>
            </div>

            <!-- GRADES TAB -->
            <div v-if="activeTab === 'grades'" class="card">
              <h3 class="font-semibold text-slate-800 mb-4">
                {{ selSubject.subject.name }} — Группа {{ selSubject.group.name }}
              </h3>
              <div class="overflow-x-auto">
                <table class="w-full text-sm">
                  <thead><tr class="bg-slate-50 border-b">
                    <th class="th">Студент</th>
                    <th class="th">Оценки</th>
                    <th class="th w-24">Выставить</th>
                  </tr></thead>
                  <tbody>
                    <tr v-for="student in selSubject.group.students" :key="student.id" class="table-row">
                      <td class="td font-medium">{{ student.user.name }}</td>
                      <td class="td">
                        <div class="flex flex-wrap gap-1.5 items-center">
                          <span v-for="g in grades.filter(g => g.student.id === student.id)" :key="g.id"
                            :class="['badge font-bold', gradeColor(g.value)]">
                            {{ g.value }}
                            <button @click="deleteGrade(g.id)" class="ml-1 opacity-50 hover:opacity-100">×</button>
                          </span>
                          <span v-if="!grades.filter(g => g.student.id === student.id).length"
                            class="text-slate-400 text-xs">—</span>
                        </div>
                      </td>
                      <td class="td">
                        <GradeInput
                          :studentId="student.id"
                          :subjectId="selSubject.subjectId"
                          @added="(g) => grades.push(g)"
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <!-- ATTENDANCE TAB -->
            <div v-if="activeTab === 'attendance'" class="card">
              <div class="flex items-center gap-4 mb-4 flex-wrap">
                <div>
                  <label class="label">Дата</label>
                  <input v-model="attendanceDate" type="date" class="input w-40" @change="loadAttendance" />
                </div>
                <div>
                  <label class="label">Пара</label>
                  <select v-model="lessonNum" class="input w-28" @change="loadAttendance">
                    <option v-for="n in 6" :key="n" :value="n">{{ n }} пара</option>
                  </select>
                </div>
                <div class="pt-5">
                  <button @click="saveAttendance" class="btn-primary"><AppIcon name="save" class="w-4 h-4" /> Сохранить</button>
                </div>
              </div>
              <table class="w-full text-sm">
                <thead><tr class="bg-slate-50 border-b">
                  <th class="th">Студент</th>
                  <th class="th text-center">Присутствовал</th>
                </tr></thead>
                <tbody>
                  <tr v-for="s in attendanceStudents" :key="s.id" class="table-row">
                    <td class="td font-medium">{{ s.user.name }}</td>
                    <td class="td text-center">
                      <button @click="s.present = !s.present"
                        :class="['w-8 h-8 rounded-full transition-colors text-lg',
                          s.present ? 'bg-green-100 hover:bg-green-200' : 'bg-red-100 hover:bg-red-200']"
                      ><AppIcon :name="s.present ? 'check' : 'x-mark'" class="w-5 h-5" /></button>
                    </td>
                  </tr>
                  <tr v-if="!attendanceStudents.length">
                    <td colspan="2" class="td text-center text-slate-400">Нет студентов</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </template>
        </div>
      </div>
    </template>
  </div>
</template>
