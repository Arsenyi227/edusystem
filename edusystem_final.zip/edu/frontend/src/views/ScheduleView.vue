<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useAuthStore } from '../stores/auth'
import { scheduleApi } from '../api'
import AppIcon from '../components/AppIcon.vue'

const auth = useAuthStore()
const entries    = ref<any[]>([])
const groups     = ref<any[]>([])
const selGroup   = ref<number | null>(null)
const loading    = ref(false)
const genMsg     = ref('')
const genErr     = ref('')
const generating = ref(false)

const DAYS  = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница']
const TIMES = ['08:00–08:45', '09:00–09:45', '10:00–10:45', '11:00–11:45', '12:00–12:45', '13:00–13:45']
const COLORS = [
  'bg-blue-50 border-blue-200 text-blue-800',
  'bg-emerald-50 border-emerald-200 text-emerald-800',
  'bg-violet-50 border-violet-200 text-violet-800',
  'bg-amber-50 border-amber-200 text-amber-800',
  'bg-rose-50 border-rose-200 text-rose-800',
  'bg-cyan-50 border-cyan-200 text-cyan-800',
  'bg-orange-50 border-orange-200 text-orange-800',
]
const colorMap = new Map<number, number>()
function subjectColor(id: number) {
  if (!colorMap.has(id)) colorMap.set(id, colorMap.size % COLORS.length)
  return COLORS[colorMap.get(id)!]
}
function cell(day: number, lesson: number) {
  return entries.value.find(e => e.dayOfWeek === day + 1 && e.lessonNum === lesson + 1) || null
}

async function load() {
  loading.value = true
  try {
    if (auth.isStudent) {
      entries.value = (await scheduleApi.getStudent()).data
    } else if (auth.isTeacher && !auth.isAdmin) {
      entries.value = (await scheduleApi.getMine()).data
    } else if (selGroup.value) {
      entries.value = (await scheduleApi.getForGroup(selGroup.value)).data
    }
  } finally { loading.value = false }
}

async function generate() {
  generating.value = true; genMsg.value = ''; genErr.value = ''
  try {
    const r = await scheduleApi.generate()
    genMsg.value = r.data.message
    await load()
  } catch (e: any) {
    genErr.value = e.response?.data?.error || 'Ошибка генерации'
  } finally { generating.value = false }
}

async function clearSchedule() {
  if (!confirm('Очистить всё расписание?')) return
  await scheduleApi.clear()
  entries.value = []
}

onMounted(async () => {
  if (auth.isAdmin) {
    groups.value = (await scheduleApi.getGroups()).data
    if (groups.value.length) { selGroup.value = groups.value[0].id; await load() }
  } else {
    await load()
  }
})
watch(selGroup, () => { if (auth.isAdmin) load() })
</script>

<template>
  <div class="p-8">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-4">
      <div>
        <h1 class="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <AppIcon name="calendar" class="w-7 h-7 text-blue-500" /> Расписание
        </h1>
        <p class="text-slate-500 text-sm mt-1">Недельная сетка занятий</p>
      </div>
      <div class="flex items-center gap-3 flex-wrap">
        <select v-if="auth.isAdmin" v-model="selGroup" class="input w-48">
          <option v-for="g in groups" :key="g.id" :value="g.id">Группа {{ g.name }}</option>
        </select>
        <template v-if="auth.isAdmin">
          <button @click="generate" :disabled="generating" class="btn-primary">
            <AppIcon :name="generating ? 'refresh' : 'lightning'"
              :class="'w-4 h-4' + (generating ? ' animate-spin' : '')" />
            {{ generating ? 'Генерация...' : 'Сгенерировать' }}
          </button>
          <button @click="clearSchedule" class="btn-danger btn-sm">
            <AppIcon name="trash" class="w-4 h-4" /> Очистить
          </button>
        </template>
      </div>
    </div>

    <div v-if="genMsg" class="mb-4 text-sm text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-2 flex items-center gap-2">
      <AppIcon name="check" class="w-4 h-4" /> {{ genMsg }}
    </div>
    <div v-if="genErr" class="mb-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-2 flex items-center gap-2">
      <AppIcon name="warning" class="w-4 h-4" /> {{ genErr }}
    </div>

    <div v-if="loading" class="text-slate-500 flex items-center gap-2 py-8">
      <AppIcon name="refresh" class="w-5 h-5 animate-spin" /> Загрузка...
    </div>

    <div v-else class="card overflow-x-auto p-0">
      <table class="w-full min-w-[800px]">
        <thead>
          <tr class="bg-slate-50 border-b border-slate-200">
            <th class="th w-28 px-4 py-3">Время</th>
            <th v-for="d in DAYS" :key="d" class="th text-center py-3">{{ d }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(time, li) in TIMES" :key="li" class="border-b border-slate-100 last:border-0">
            <td class="px-4 py-3 w-28">
              <div class="text-xs font-bold text-slate-700">{{ li + 1 }} пара</div>
              <div class="text-xs text-slate-500 mt-0.5">{{ time }}</div>
            </td>
            <td v-for="(_, di) in DAYS" :key="di" class="px-2 py-2 align-top">
              <template v-if="cell(di, li)">
                <div :class="['rounded-lg border p-2 text-xs text-left', subjectColor(cell(di, li)!.subjectId)]">
                  <div class="font-semibold leading-tight">{{ cell(di, li)!.subject.name }}</div>
                  <div v-if="cell(di, li)!.group"  class="opacity-70 mt-0.5">Гр. {{ cell(di, li)!.group.name }}</div>
                  <div v-if="cell(di, li)!.teacher" class="opacity-70 truncate">{{ cell(di, li)!.teacher.user.name }}</div>
                </div>
              </template>
              <template v-else>
                <div class="min-h-[52px] rounded-lg bg-slate-50 border border-dashed border-slate-200"></div>
              </template>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="!loading && !entries.length && !generating" class="text-center py-12 text-slate-400">
      <AppIcon name="calendar" class="w-12 h-12 mx-auto mb-3 opacity-40" />
      <p class="font-medium">Расписание не сгенерировано</p>
      <p v-if="auth.isAdmin" class="text-sm mt-1">Добавьте предметы и группы, затем нажмите «Сгенерировать»</p>
    </div>
  </div>
</template>
