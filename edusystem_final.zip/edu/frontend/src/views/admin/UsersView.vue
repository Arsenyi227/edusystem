<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { adminApi } from '../../api'
import GroupsPanel   from '../../components/GroupsPanel.vue'
import SubjectsPanel from '../../components/SubjectsPanel.vue'
import AppIcon from '../../components/AppIcon.vue'

const users     = ref<any[]>([])
const groups    = ref<any[]>([])
const loading   = ref(true)
const showModal = ref(false)
const editUser  = ref<any>(null)
const saving    = ref(false)
const formErr   = ref('')
const filter    = ref('')
const form = ref({ name: '', email: '', password: '', role: 'STUDENT' as 'STUDENT'|'TEACHER', groupId: '' })

const filtered = computed(() =>
  users.value.filter(u =>
    u.name.toLowerCase().includes(filter.value.toLowerCase()) ||
    u.email.toLowerCase().includes(filter.value.toLowerCase())
  )
)
const roleLabel: Record<string,string> = { ADMIN:'Администратор', TEACHER:'Преподаватель', STUDENT:'Студент' }
const roleBadge: Record<string,string> = { ADMIN:'badge-red', TEACHER:'badge-blue', STUDENT:'badge-green' }

async function load() {
  const [u, g] = await Promise.all([adminApi.getUsers(), adminApi.getGroups()])
  users.value = u.data; groups.value = g.data
}

function openCreate() {
  editUser.value = null
  form.value = { name:'', email:'', password:'', role:'STUDENT', groupId:'' }
  formErr.value = ''; showModal.value = true
}
function openEdit(u: any) {
  editUser.value = u
  form.value = { name:u.name, email:u.email, password:'', role:u.role, groupId:u.student?.group?.id||'' }
  formErr.value = ''; showModal.value = true
}

async function save() {
  if (!form.value.name || !form.value.email) { formErr.value = 'Имя и email обязательны'; return }
  if (!editUser.value && !form.value.password) { formErr.value = 'Пароль обязателен'; return }
  saving.value = true; formErr.value = ''
  try {
    const data: any = { name: form.value.name, email: form.value.email, role: form.value.role }
    if (form.value.password) data.password = form.value.password
    if (form.value.role === 'STUDENT' && form.value.groupId) data.groupId = Number(form.value.groupId)
    editUser.value ? await adminApi.updateUser(editUser.value.id, data) : await adminApi.createUser(data)
    await load(); showModal.value = false
  } catch (e: any) { formErr.value = e.response?.data?.error || 'Ошибка' }
  finally { saving.value = false }
}

async function del(id: number, name: string) {
  if (!confirm(`Удалить пользователя ${name}?`)) return
  await adminApi.deleteUser(id)
  users.value = users.value.filter(u => u.id !== id)
}

onMounted(async () => { await load(); loading.value = false })
</script>

<template>
  <div class="p-8">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-4">
      <div>
        <h1 class="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <AppIcon name="users" class="w-7 h-7 text-blue-500" /> Пользователи
        </h1>
        <p class="text-slate-500 text-sm mt-1">{{ users.length }} пользователей в системе</p>
      </div>
      <button @click="openCreate" class="btn-primary">
        <AppIcon name="plus" class="w-4 h-4" /> Добавить пользователя
      </button>
    </div>

    <div class="card mb-4 py-3 flex items-center gap-2">
      <AppIcon name="home" class="w-4 h-4 text-slate-400 ml-1" />
      <input v-model="filter" class="flex-1 outline-none text-sm text-slate-700 placeholder-slate-400"
        placeholder="Поиск по имени или email..." />
    </div>

    <div v-if="loading" class="text-slate-500 flex items-center gap-2 py-8">
      <AppIcon name="refresh" class="w-5 h-5 animate-spin" /> Загрузка...
    </div>

    <div v-else class="card p-0 overflow-hidden">
      <table class="w-full">
        <thead>
          <tr class="bg-slate-50 border-b border-slate-200">
            <th class="th">Имя</th><th class="th">Email</th><th class="th">Роль</th>
            <th class="th">Группа</th><th class="th">Добавлен</th><th class="th w-24"></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="u in filtered" :key="u.id" class="table-row">
            <td class="td">
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {{ u.name[0] }}
                </div>
                <span class="font-medium">{{ u.name }}</span>
              </div>
            </td>
            <td class="td text-slate-500">{{ u.email }}</td>
            <td class="td"><span :class="['badge', roleBadge[u.role]]">{{ roleLabel[u.role] }}</span></td>
            <td class="td text-slate-500">{{ u.student?.group?.name || '—' }}</td>
            <td class="td text-slate-500 text-xs">{{ new Date(u.createdAt).toLocaleDateString('ru-RU') }}</td>
            <td class="td">
              <div class="flex gap-1">
                <button @click="openEdit(u)" class="btn-secondary btn-sm p-1.5">
                  <AppIcon name="pencil" class="w-4 h-4" />
                </button>
                <button @click="del(u.id, u.name)" class="btn-danger btn-sm p-1.5" :disabled="u.role==='ADMIN'">
                  <AppIcon name="trash" class="w-4 h-4" />
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="!filtered.length">
            <td colspan="6" class="td text-center text-slate-400 py-8">Пользователи не найдены</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
      <GroupsPanel :groups="groups" @updated="load" />
      <SubjectsPanel @updated="load" />
    </div>

    <!-- Modal -->
    <div v-if="showModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 class="font-semibold flex items-center gap-2">
            <AppIcon name="users" class="w-5 h-5 text-blue-500" />
            {{ editUser ? 'Редактировать пользователя' : 'Новый пользователь' }}
          </h2>
          <button @click="showModal = false" class="text-slate-400 hover:text-slate-600 rounded-lg p-1 hover:bg-slate-100">
            <AppIcon name="x-mark" class="w-5 h-5" />
          </button>
        </div>
        <div class="p-6 space-y-4">
          <div><label class="label">Полное имя *</label>
            <input v-model="form.name" class="input" placeholder="Иванов Иван Иванович" /></div>
          <div><label class="label">Email *</label>
            <input v-model="form.email" type="email" class="input" placeholder="user@school.kz" /></div>
          <div><label class="label">Пароль {{ editUser ? '(оставьте пустым)' : '*' }}</label>
            <input v-model="form.password" type="password" class="input" placeholder="••••••••" /></div>
          <div>
            <label class="label">Роль *</label>
            <select v-model="form.role" class="input">
              <option value="STUDENT">Студент</option>
              <option value="TEACHER">Преподаватель</option>
            </select>
          </div>
          <div v-if="form.role === 'STUDENT'">
            <label class="label">Группа</label>
            <select v-model="form.groupId" class="input">
              <option value="">— Выберите группу —</option>
              <option v-for="g in groups" :key="g.id" :value="g.id">{{ g.name }}</option>
            </select>
          </div>
          <div v-if="formErr" class="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2 flex items-center gap-2">
            <AppIcon name="warning" class="w-4 h-4 flex-shrink-0" /> {{ formErr }}
          </div>
        </div>
        <div class="px-6 py-4 border-t border-slate-200 flex justify-end gap-3">
          <button @click="showModal = false" class="btn-secondary">Отмена</button>
          <button @click="save" :disabled="saving" class="btn-primary">
            <AppIcon :name="saving ? 'refresh' : 'check'" :class="'w-4 h-4' + (saving ? ' animate-spin' : '')" />
            {{ saving ? 'Сохранение...' : (editUser ? 'Сохранить' : 'Создать') }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
