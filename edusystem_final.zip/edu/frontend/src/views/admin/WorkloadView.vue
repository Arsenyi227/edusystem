<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { adminApi } from '../../api'
import AppIcon from '../../components/AppIcon.vue'

const workload  = ref<any[]>([])
const formData  = ref<{ teachers: any[]; subjects: any[]; groups: any[] }>({ teachers: [], subjects: [], groups: [] })
const loading   = ref(true)
const showModal = ref(false)
const saving    = ref(false)
const formErr   = ref('')
const form      = ref({ subjectId: '', groupId: '', teacherId: '', hoursPerWeek: 2 })

// Группируем по предмету → группе
const bySubject = computed(() => {
  const map = new Map<number, { subject: any; rows: any[] }>()
  for (const row of workload.value) {
    if (!map.has(row.subjectId)) map.set(row.subjectId, { subject: row.subject, rows: [] })
    map.get(row.subjectId)!.rows.push(row)
  }
  return [...map.values()].sort((a, b) => a.subject.name.localeCompare(b.subject.name))
})

// Для выбранного предмета — сколько преподавателей ведут его
function teachersForSubject(subjectId: number) {
  return formData.value.teachers.filter(t =>
    workload.value.some(w => w.subjectId === subjectId && w.teacherId === t.id)
  )
}

async function load() {
  const [w, fd] = await Promise.all([adminApi.getWorkload(), adminApi.getWorkloadFD()])
  workload.value = w.data; formData.value = fd.data
}

async function openModal() {
  form.value = { subjectId: '', groupId: '', teacherId: '', hoursPerWeek: 2 }
  formErr.value = ''
  showModal.value = true
  if (!formData.value.teachers.length) {
    const fd = await adminApi.getWorkloadFD()
    formData.value = fd.data
  }
}

// Автовыбор преподавателя если он один для выбранного предмета
const filteredTeachers = computed(() => {
  if (!form.value.subjectId) return formData.value.teachers
  // показываем всех учителей — admin может назначить любого на предмет
  return formData.value.teachers
})

async function save() {
  if (!form.value.subjectId || !form.value.groupId || !form.value.teacherId) {
    formErr.value = 'Заполните все поля'; return
  }
  saving.value = true; formErr.value = ''
  try {
    await adminApi.createWorkload({ ...form.value })
    await load(); showModal.value = false
  } catch (e: any) {
    formErr.value = e.response?.data?.error || 'Ошибка'
  } finally { saving.value = false }
}

// Изменить преподавателя прямо в таблице
async function changeTeacher(rowId: number, teacherId: string) {
  if (!teacherId) return
  await adminApi.updateWorkload(rowId, { teacherId: Number(teacherId) })
  await load()
}

async function changeHours(rowId: number, hours: number) {
  await adminApi.updateWorkload(rowId, { hoursPerWeek: hours })
  await load()
}

async function del(id: number) {
  if (!confirm('Удалить запись нагрузки?')) return
  await adminApi.deleteWorkload(id); await load()
}

onMounted(async () => { await load(); loading.value = false })
</script>

<template>
  <div class="p-8">
    <div class="flex items-center justify-between mb-6 flex-wrap gap-4">
      <div>
        <h1 class="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <AppIcon name="chart" class="w-7 h-7 text-blue-600" /> Расчасовка
        </h1>
        <p class="text-slate-500 text-sm mt-1">Назначение преподавателей по предметам и группам</p>
      </div>
      <button @click="openModal" class="btn-primary">
        <AppIcon name="plus" class="w-4 h-4" /> Добавить запись
      </button>
    </div>

    <!-- Info banner -->
    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 text-sm text-blue-800 flex gap-3">
      <AppIcon name="info" class="w-5 h-5 flex-shrink-0 mt-0.5" />
      <div>
        <strong>Как работает:</strong> Укажите для каждого предмета и группы преподавателя и количество часов в неделю.
        Если предмет ведут несколько преподавателей — назначьте каждого отдельной строкой.
        После заполнения расчасовки администратор генерирует расписание в разделе <strong>«Расписание»</strong>.
      </div>
    </div>

    <div v-if="loading" class="text-slate-400 flex items-center gap-2 py-8">
      <AppIcon name="refresh" class="w-5 h-5 animate-spin" /> Загрузка...
    </div>

    <!-- Grouped by subject -->
    <div v-else class="space-y-4">
      <div v-for="group in bySubject" :key="group.subject.id" class="card p-0 overflow-hidden">
        <!-- Subject header -->
        <div class="flex items-center gap-3 px-6 py-3 bg-slate-50 border-b border-slate-200">
          <AppIcon name="subject" class="w-4 h-4 text-slate-500" />
          <span class="font-semibold text-slate-800">{{ group.subject.name }}</span>
          <span class="badge-blue badge ml-auto">{{ group.rows.length }} {{ group.rows.length === 1 ? 'запись' : 'записей' }}</span>
        </div>

        <table class="w-full">
          <thead><tr class="border-b border-slate-100">
            <th class="th">Группа</th>
            <th class="th">Преподаватель</th>
            <th class="th w-32 text-center">Часов/нед</th>
            <th class="th w-16"></th>
          </tr></thead>
          <tbody>
            <tr v-for="row in group.rows" :key="row.id" class="table-row">
              <td class="td font-medium">
                <span class="badge bg-slate-100 text-slate-700">{{ row.group.name }}</span>
              </td>
              <td class="td">
                <!-- Если преподаватель один — просто показываем имя -->
                <!-- Если несколько доступно — показываем выпадающий список -->
                <select
                  :value="row.teacherId"
                  @change="changeTeacher(row.id, ($event.target as HTMLSelectElement).value)"
                  class="input !py-1 text-sm"
                >
                  <option v-for="t in formData.teachers" :key="t.id" :value="t.id">
                    {{ t.user.name }}
                  </option>
                </select>
              </td>
              <td class="td text-center">
                <input
                  type="number" min="1" max="6"
                  :value="row.hoursPerWeek"
                  @change="changeHours(row.id, Number(($event.target as HTMLInputElement).value))"
                  class="input !py-1 !px-2 w-16 text-center text-sm"
                />
              </td>
              <td class="td">
                <button @click="del(row.id)" class="text-slate-400 hover:text-red-500 transition-colors">
                  <AppIcon name="trash" class="w-4 h-4" />
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div v-if="!bySubject.length" class="card text-center py-16 text-slate-400 border-dashed">
        <AppIcon name="chart" class="w-12 h-12 mx-auto mb-3 opacity-30" />
        <p class="font-medium text-lg">Расчасовка пуста</p>
        <p class="text-sm mt-1">Нажмите «Добавить запись» чтобы назначить преподавателя на предмет</p>
      </div>
    </div>

    <!-- Modal -->
    <div v-if="showModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 class="font-semibold text-slate-800">Добавить запись расчасовки</h2>
          <button @click="showModal = false" class="text-slate-400 hover:text-slate-600 text-xl">×</button>
        </div>
        <div class="p-6 space-y-4">
          <div>
            <label class="label">Предмет *</label>
            <select v-model="form.subjectId" class="input">
              <option value="">— Выберите предмет —</option>
              <option v-for="s in formData.subjects" :key="s.id" :value="s.id">{{ s.name }}</option>
            </select>
          </div>
          <div>
            <label class="label">Группа *</label>
            <select v-model="form.groupId" class="input">
              <option value="">— Выберите группу —</option>
              <option v-for="g in formData.groups" :key="g.id" :value="g.id">{{ g.name }}</option>
            </select>
          </div>
          <div>
            <label class="label">Преподаватель *</label>
            <select v-model="form.teacherId" class="input">
              <option value="">— Выберите преподавателя —</option>
              <option v-for="t in filteredTeachers" :key="t.id" :value="t.id">{{ t.user.name }}</option>
            </select>
            <p v-if="!formData.teachers.length" class="text-xs text-amber-600 mt-1">
              ⚠️ Нет преподавателей. Добавьте их в разделе «Пользователи».
            </p>
          </div>
          <div>
            <label class="label">Часов в неделю</label>
            <input v-model.number="form.hoursPerWeek" type="number" min="1" max="6" class="input" />
            <p class="text-xs text-slate-400 mt-1">1–6 часов. Влияет на автогенерацию расписания.</p>
          </div>
          <div v-if="formErr" class="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{{ formErr }}</div>
        </div>
        <div class="px-6 py-4 border-t border-slate-200 flex justify-end gap-3">
          <button @click="showModal = false" class="btn-secondary">Отмена</button>
          <button @click="save" :disabled="saving" class="btn-primary">
            {{ saving ? '⏳...' : 'Добавить' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
