import axios from 'axios'
export const api = axios.create({ baseURL: '/api' })
api.interceptors.request.use(c => { const t = localStorage.getItem('token'); if (t) c.headers.Authorization = `Bearer ${t}`; return c })
api.interceptors.response.use(r => r, e => { if (e.response?.status === 401) { localStorage.removeItem('token'); localStorage.removeItem('user'); window.location.href = '/login' } return Promise.reject(e) })

export const login = (email: string, password: string) => api.post<{ token: string; user: any }>('/auth/login', { email, password })

export const adminApi = {
  getUsers:       ()              => api.get('/admin/users'),
  createUser:     (d: any)        => api.post('/admin/users', d),
  updateUser:     (id: number, d: any) => api.patch(`/admin/users/${id}`, d),
  deleteUser:     (id: number)    => api.delete(`/admin/users/${id}`),
  getGroups:      ()              => api.get('/admin/groups'),
  createGroup:    (name: string)  => api.post('/admin/groups', { name }),
  deleteGroup:    (id: number)    => api.delete(`/admin/groups/${id}`),
  getSubjects:    ()              => api.get('/admin/subjects'),
  createSubject:  (name: string)  => api.post('/admin/subjects', { name }),
  deleteSubject:  (id: number)    => api.delete(`/admin/subjects/${id}`),
  getStats:       ()              => api.get('/admin/stats'),
  // Workload
  getWorkload:        ()              => api.get('/admin/workload'),
  getWorkloadFD:      ()              => api.get('/admin/workload/form-data'),
  createWorkload:     (d: any)        => api.post('/admin/workload', d),
  updateWorkload:     (id: number, d: any) => api.patch(`/admin/workload/${id}`, d),
  deleteWorkload:     (id: number)    => api.delete(`/admin/workload/${id}`),
}

export const teacherApi = {
  getMySubjects:  ()              => api.get('/teacher/my-subjects'),
  addSubject:     (d: any)        => api.post('/teacher/my-subjects', d),
  removeSubject:  (id: number)    => api.delete(`/teacher/my-subjects/${id}`),
  getGrades:      (p?: any)       => api.get('/teacher/grades', { params: p }),
  addGrade:       (d: any)        => api.post('/teacher/grades', d),
  deleteGrade:    (id: number)    => api.delete(`/teacher/grades/${id}`),
  getAttendance:  (p?: any)       => api.get('/teacher/attendance', { params: p }),
  saveAttendance: (d: any[])      => api.post('/teacher/attendance', d),
  getAssignments: ()              => api.get('/teacher/assignments'),
  addAssignment:  (d: any)        => api.post('/teacher/assignments', d),
  deleteAssignment:(id: number)   => api.delete(`/teacher/assignments/${id}`),
  getFormData:    ()              => api.get('/teacher/form-data'),
}

export const studentApi = {
  getDiary:       ()              => api.get('/student/diary'),
  getAttendance:  ()              => api.get('/student/attendance'),
}

export const scheduleApi = {
  getForGroup:    (groupId: number) => api.get(`/schedule/group/${groupId}`),
  getMine:        ()              => api.get('/schedule/my'),
  getStudent:     ()              => api.get('/schedule/student'),
  generate:       ()              => api.post('/schedule/generate'),
  clear:          ()              => api.delete('/schedule/clear'),
  getGroups:      ()              => api.get('/schedule/groups'),
}
