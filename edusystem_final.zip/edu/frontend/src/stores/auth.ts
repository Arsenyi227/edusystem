import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { login } from '../api'
export type UserRole = 'ADMIN' | 'TEACHER' | 'STUDENT'
export interface AuthUser { id: number; name: string; role: UserRole }
export const useAuthStore = defineStore('auth', () => {
  const token = ref<string | null>(localStorage.getItem('token'))
  const user  = ref<AuthUser | null>(JSON.parse(localStorage.getItem('user') || 'null'))
  const isLoggedIn = computed(() => !!token.value)
  const isAdmin    = computed(() => user.value?.role === 'ADMIN')
  const isTeacher  = computed(() => user.value?.role === 'TEACHER')
  const isStudent  = computed(() => user.value?.role === 'STUDENT')
  async function signIn(email: string, password: string) {
    const { data } = await login(email, password)
    token.value = data.token; user.value = data.user as AuthUser
    localStorage.setItem('token', data.token); localStorage.setItem('user', JSON.stringify(data.user))
  }
  function signOut() {
    token.value = null; user.value = null
    localStorage.removeItem('token'); localStorage.removeItem('user')
  }
  return { token, user, isLoggedIn, isAdmin, isTeacher, isStudent, signIn, signOut }
})
