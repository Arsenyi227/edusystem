<script setup lang="ts">
import { ref } from 'vue'
import { adminApi } from '../api'
import AppIcon from './AppIcon.vue'

defineProps<{ groups: any[] }>()
const emit = defineEmits<{ updated: [] }>()
const name = ref(''); const saving = ref(false)

async function add() {
  if (!name.value.trim()) return
  saving.value = true
  try { await adminApi.createGroup(name.value.trim()); name.value = ''; emit('updated') }
  finally { saving.value = false }
}
async function del(id: number) {
  if (!confirm('Удалить группу?')) return
  await adminApi.deleteGroup(id); emit('updated')
}
</script>
<template>
  <div class="card">
    <h3 class="font-semibold text-slate-800 mb-3 flex items-center gap-2">
      <AppIcon name="group" class="w-5 h-5 text-purple-500" /> Группы
    </h3>
    <div class="flex gap-2 mb-3">
      <input v-model="name" class="input flex-1" placeholder="Название группы (10А)" @keyup.enter="add" />
      <button @click="add" :disabled="saving" class="btn-primary btn-sm">
        <AppIcon name="plus" class="w-4 h-4" />
      </button>
    </div>
    <div class="space-y-1 max-h-48 overflow-y-auto">
      <div v-for="g in groups" :key="g.id"
        class="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors">
        <span class="text-sm font-medium">{{ g.name }}</span>
        <div class="flex items-center gap-2">
          <span class="text-xs text-slate-400">{{ g._count?.students || 0 }} студ.</span>
          <button @click="del(g.id)" class="text-slate-400 hover:text-red-500 transition-colors">
            <AppIcon name="trash" class="w-4 h-4" />
          </button>
        </div>
      </div>
      <div v-if="!groups.length" class="text-xs text-slate-400 text-center py-3">Нет групп</div>
    </div>
  </div>
</template>
