<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { adminApi } from '../api'
import AppIcon from './AppIcon.vue'

const emit = defineEmits<{ updated: [] }>()
const subjects = ref<any[]>([]); const name = ref(''); const saving = ref(false)

onMounted(async () => { subjects.value = (await adminApi.getSubjects()).data })

async function add() {
  if (!name.value.trim()) return
  saving.value = true
  try {
    const r = await adminApi.createSubject(name.value.trim())
    subjects.value.push(r.data); name.value = ''; emit('updated')
  } finally { saving.value = false }
}
async function del(id: number) {
  if (!confirm('Удалить предмет?')) return
  await adminApi.deleteSubject(id)
  subjects.value = subjects.value.filter(s => s.id !== id); emit('updated')
}
</script>
<template>
  <div class="card">
    <h3 class="font-semibold text-slate-800 mb-3 flex items-center gap-2">
      <AppIcon name="book-stack" class="w-5 h-5 text-amber-500" /> Предметы
    </h3>
    <div class="flex gap-2 mb-3">
      <input v-model="name" class="input flex-1" placeholder="Название предмета" @keyup.enter="add" />
      <button @click="add" :disabled="saving" class="btn-primary btn-sm">
        <AppIcon name="plus" class="w-4 h-4" />
      </button>
    </div>
    <div class="space-y-1 max-h-48 overflow-y-auto">
      <div v-for="s in subjects" :key="s.id"
        class="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors">
        <span class="text-sm font-medium">{{ s.name }}</span>
        <button @click="del(s.id)" class="text-slate-400 hover:text-red-500 transition-colors">
          <AppIcon name="trash" class="w-4 h-4" />
        </button>
      </div>
      <div v-if="!subjects.length" class="text-xs text-slate-400 text-center py-3">Нет предметов</div>
    </div>
  </div>
</template>
