<script setup lang="ts">
import { ref } from 'vue'
import { teacherApi } from '../api'

const props = defineProps<{ studentId: number; subjectId: number }>()
const emit  = defineEmits<{ added: [grade: any] }>()

const val     = ref('')
const comment = ref('')

async function add() {
  if (!val.value) return
  try {
    const r = await teacherApi.addGrade({
      studentId: props.studentId,
      subjectId: props.subjectId,
      value: Number(val.value),
      comment: comment.value,
    })
    emit('added', r.data)
    val.value = ''
    comment.value = ''
  } catch (e: any) {
    alert(e.response?.data?.error || 'Ошибка')
  }
}
</script>

<template>
  <div class="flex gap-1 items-center">
    <select v-model="val" class="input !py-1 !px-2 w-16 text-xs">
      <option value="">—</option>
      <option v-for="n in [1, 2, 3, 4, 5]" :key="n" :value="n">{{ n }}</option>
    </select>
    <button @click="add" class="btn-primary btn-sm px-2 py-1">+</button>
  </div>
</template>
