<script setup lang="ts">
import { computed } from 'vue'
import { useRouter, RouterLink, RouterView } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import AppIcon from './AppIcon.vue'
const auth = useAuthStore()
const router = useRouter()
function logout() { auth.signOut(); router.push('/login') }
const nav = computed(() => {
  const items: { to: string; icon: string; label: string }[] = [
    { to: '/dashboard', icon: 'home', label: 'Дашборд' },
    { to: '/schedule',  icon: 'calendar', label: 'Расписание' },
  ]
  if (auth.isStudent || auth.isTeacher || auth.isAdmin)
    items.push({ to: '/diary', icon: 'book', label: auth.isStudent ? 'Мой дневник' : 'Дневник' })
  if (auth.isTeacher || auth.isAdmin) {
    items.push(
      { to: '/teacher/grades', icon: 'pencil', label: 'Оценки' },
      { to: '/teacher/assignments', icon: 'clipboard', label: 'Задания' },
    )
  }
  if (auth.isAdmin) {
    items.push(
      { to: '/admin/workload', icon: 'chart', label: 'Расчасовка' },
      { to: '/admin/users', icon: 'users', label: 'Пользователи' },
    )
  }
  return items
})
const roleLabel: Record<string,string> = { ADMIN: 'Администратор', TEACHER: 'Преподаватель', STUDENT: 'Студент' }
const roleBadge: Record<string,string> = { ADMIN: 'badge-red', TEACHER: 'badge-blue', STUDENT: 'badge-green' }
const initials = computed(() => {
  const parts = (auth.user?.name ?? '?').split(' ')
  return parts.slice(0,2).map(p => p[0]).join('').toUpperCase()
})
</script>
<template>
  <div class="flex h-screen overflow-hidden bg-slate-50">
    <aside class="w-64 flex-shrink-0 bg-slate-900 flex flex-col">
      <div class="flex items-center gap-3 px-5 py-5 border-b border-slate-700/60">
        <div class="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
          <AppIcon name="graduate" class="w-5 h-5 text-white" />
        </div>
        <div>
          <div class="text-white font-bold text-sm leading-tight">EduSystem</div>
          <div class="text-slate-400 text-xs mt-0.5">Образовательная среда</div>
        </div>
      </div>
      <nav class="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        <RouterLink v-for="item in nav" :key="item.to" :to="item.to"
          class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white transition-all duration-150 text-sm font-medium"
          active-class="!bg-blue-600/20 !text-blue-400 hover:!bg-blue-600/30">
          <AppIcon :name="item.icon" class="w-5 h-5 flex-shrink-0" />
          {{ item.label }}
        </RouterLink>
      </nav>
      <div class="px-3 py-4 border-t border-slate-700/60">
        <div class="flex items-center gap-3 px-3 py-2 mb-1">
          <div class="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xs flex-shrink-0">{{ initials }}</div>
          <div class="overflow-hidden flex-1">
            <div class="text-white text-sm font-medium truncate leading-tight">{{ auth.user?.name }}</div>
            <span :class="['badge text-xs mt-0.5', roleBadge[auth.user?.role ?? '']]">{{ roleLabel[auth.user?.role ?? ''] }}</span>
          </div>
        </div>
        <button @click="logout" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-all duration-150 text-sm font-medium">
          <AppIcon name="logout" class="w-5 h-5 flex-shrink-0" /> Выйти
        </button>
      </div>
    </aside>
    <main class="flex-1 overflow-y-auto"><RouterView /></main>
  </div>
</template>
