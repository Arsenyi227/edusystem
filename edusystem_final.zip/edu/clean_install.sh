#!/usr/bin/env bash
# =============================================================================
#  EduSystem — ЧИСТАЯ УСТАНОВКА (сначала сносит всё, потом ставит заново)
#  Использование: sudo bash clean_install.sh [--domain example.com]
# =============================================================================
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}✓${NC} $*"; }
info() { echo -e "${YELLOW}→${NC} $*"; }
warn() { echo -e "${RED}!${NC} $*"; }
step() { echo -e "\n${CYAN}━━━ $* ━━━${NC}"; }

[[ $EUID -ne 0 ]] && { warn "Запустите с правами root: sudo bash clean_install.sh"; exit 1; }

APP_DIR="/opt/edusystem"
DB_NAME="edudb"
DB_USER="eduuser"
NGINX_CONF="/etc/nginx/sites-available/edusystem"
NGINX_LINK="/etc/nginx/sites-enabled/edusystem"

# ════════════════════════════════════════════════════════════════════════════
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║     EduSystem — Очистка и чистая установка           ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
warn "Это удалит ВСЕ данные EduSystem (БД, файлы, конфиги)."
read -rp "Продолжить? [y/N]: " confirm
[[ "${confirm,,}" == "y" ]] || { echo "Отменено."; exit 0; }

# ════════════════════════════════════════════════════════════════════════════
step "1. Остановка процессов PM2"

if command -v pm2 &>/dev/null; then
  pm2 delete edusystem-backend 2>/dev/null && ok "PM2 процесс удалён" || info "PM2 процесс не найден — пропускаем"
  pm2 save --force 2>/dev/null || true
else
  info "PM2 не установлен — пропускаем"
fi

# ════════════════════════════════════════════════════════════════════════════
step "2. Удаление конфига Nginx"

if [[ -f "$NGINX_LINK" ]]; then
  rm -f "$NGINX_LINK"
  ok "Симлинк nginx удалён"
fi
if [[ -f "$NGINX_CONF" ]]; then
  rm -f "$NGINX_CONF"
  ok "Конфиг nginx удалён"
fi

# Восстанавливаем дефолтный сайт если он был
if [[ ! -f /etc/nginx/sites-enabled/default ]] && [[ -f /etc/nginx/sites-available/default ]]; then
  ln -sf /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default
  info "Дефолтный nginx сайт восстановлен"
fi

if command -v nginx &>/dev/null && nginx -t 2>/dev/null; then
  systemctl reload nginx 2>/dev/null || true
  ok "Nginx перезагружен"
fi

# ════════════════════════════════════════════════════════════════════════════
step "3. Удаление базы данных PostgreSQL"

if command -v psql &>/dev/null && systemctl is-active postgresql --quiet 2>/dev/null; then
  sudo -u postgres psql 2>/dev/null <<SQL
-- Отключаем всех активных пользователей от БД
SELECT pg_terminate_backend(pid)
  FROM pg_stat_activity
  WHERE datname = '${DB_NAME}' AND pid <> pg_backend_pid();

DROP DATABASE IF EXISTS ${DB_NAME};
DROP USER IF EXISTS ${DB_USER};
SQL
  ok "База данных '${DB_NAME}' и пользователь '${DB_USER}' удалены"
else
  info "PostgreSQL не запущен или не установлен — пропускаем"
fi

# ════════════════════════════════════════════════════════════════════════════
step "4. Удаление файлов приложения"

if [[ -d "$APP_DIR" ]]; then
  rm -rf "$APP_DIR"
  ok "Директория ${APP_DIR} удалена"
else
  info "${APP_DIR} не найдена — пропускаем"
fi

# ════════════════════════════════════════════════════════════════════════════
step "5. Очистка npm глобального кэша (опционально)"

npm cache clean --force 2>/dev/null && ok "npm кэш очищен" || true

# ════════════════════════════════════════════════════════════════════════════
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
ok "Очистка завершена. Запускаем чистую установку..."
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
sleep 1

# ════════════════════════════════════════════════════════════════════════════
# Запуск основного install.sh из той же директории
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -f "${SCRIPT_DIR}/install.sh" ]]; then
  warn "install.sh не найден рядом со скриптом (ожидался в ${SCRIPT_DIR}/install.sh)"
  exit 1
fi

bash "${SCRIPT_DIR}/install.sh" "$@"
