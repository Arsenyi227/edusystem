#!/usr/bin/env bash
# =============================================================================
#  EduSystem — Диагностика и авторемонт
#  Использование: sudo bash diagnose.sh
# =============================================================================

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}✓${NC} $*"; }
fail() { echo -e "  ${RED}✗${NC} $*"; }
warn() { echo -e "  ${YELLOW}!${NC} $*"; }
step() { echo -e "\n${CYAN}[ $* ]${NC}"; }

APP_DIR="/opt/edusystem"
BACKEND_DIR="$APP_DIR/backend"
LOG="$APP_DIR/logs/backend.log"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║     EduSystem — Диагностика              ║"
echo "╚══════════════════════════════════════════╝"

# ── 1. Системные сервисы ──────────────────────────────────────────────────────
step "Системные сервисы"

systemctl is-active postgresql --quiet && ok "PostgreSQL запущен" \
  || { fail "PostgreSQL НЕ запущен"; systemctl start postgresql && warn "PostgreSQL запущен принудительно"; }

systemctl is-active nginx --quiet && ok "Nginx запущен" \
  || { fail "Nginx НЕ запущен"; systemctl start nginx && warn "Nginx запущен принудительно"; }

# ── 2. Файлы приложения ───────────────────────────────────────────────────────
step "Файлы приложения"

[[ -d "$BACKEND_DIR" ]]              && ok "Директория backend существует"    || fail "НЕТ директории $BACKEND_DIR"
[[ -f "$BACKEND_DIR/.env" ]]         && ok ".env файл существует"             || fail "НЕТ файла .env → критично!"
[[ -d "$BACKEND_DIR/node_modules" ]] && ok "node_modules установлены"         || fail "НЕТ node_modules → нужен npm install"
[[ -f "$APP_DIR/frontend/dist/index.html" ]] && ok "Frontend собран (dist/)" || fail "Frontend НЕ собран — нужен npm run build"

# ── 3. .env содержимое ────────────────────────────────────────────────────────
step "Конфигурация .env"

if [[ -f "$BACKEND_DIR/.env" ]]; then
  source "$BACKEND_DIR/.env" 2>/dev/null || true

  [[ -n "${DATABASE_URL:-}" ]] && ok "DATABASE_URL задан"    || fail "DATABASE_URL пустой!"
  [[ -n "${JWT_SECRET:-}" ]]   && ok "JWT_SECRET задан"      || fail "JWT_SECRET пустой!"
  [[ -n "${PORT:-}" ]]         && ok "PORT = ${PORT}"        || warn "PORT не задан (будет 3000)"

  # Проверяем подключение к БД
  DB_URL="${DATABASE_URL:-}"
  if [[ -n "$DB_URL" ]]; then
    cd "$BACKEND_DIR"
    if npx prisma db execute --stdin <<< "SELECT 1;" 2>/dev/null; then
      ok "Подключение к PostgreSQL успешно"
    else
      fail "Не удалось подключиться к PostgreSQL по DATABASE_URL"
      warn "DATABASE_URL = $DB_URL"
    fi
  fi
fi

# ── 4. PM2 процесс ────────────────────────────────────────────────────────────
step "PM2 процесс"

if ! command -v pm2 &>/dev/null; then
  fail "PM2 не установлен"
  npm install -g pm2 --quiet && ok "PM2 установлен"
fi

PM2_STATUS=$(pm2 jlist 2>/dev/null | python3 -c "
import sys, json
try:
  procs = json.load(sys.stdin)
  p = next((x for x in procs if x['name'] == 'edusystem-backend'), None)
  print(p['pm2_env']['status'] if p else 'not_found')
except: print('error')
" 2>/dev/null || echo "error")

case "$PM2_STATUS" in
  online)  ok "PM2 процесс: online ✓" ;;
  stopped) fail "PM2 процесс: stopped"; warn "Попытка запустить..."; cd "$BACKEND_DIR" && pm2 start "npx tsx src/index.ts" --name edusystem-backend --time && pm2 save ;;
  errored) fail "PM2 процесс: ОШИБКА — смотри логи ниже" ;;
  not_found) fail "PM2 процесс не найден"; warn "Запускаем..."
    cd "$BACKEND_DIR" && pm2 start "npx tsx src/index.ts" --name edusystem-backend \
      --log "$APP_DIR/logs/backend.log" --time && pm2 save && ok "Запущен" ;;
  *) warn "Статус PM2 неизвестен: $PM2_STATUS" ;;
esac

# ── 5. Порт 3000 ─────────────────────────────────────────────────────────────
step "Сеть"

sleep 2  # даём backend время стартовать
if ss -tlnp 2>/dev/null | grep -q ':3000'; then
  ok "Порт 3000 слушается"
else
  fail "Порт 3000 НЕ слушается — backend не запустился"
fi

# Прямой запрос к backend
HEALTH=$(curl -sf http://localhost:3000/api/health 2>/dev/null || echo "FAIL")
if echo "$HEALTH" | grep -q "ok"; then
  ok "Backend отвечает: $HEALTH"
else
  fail "Backend НЕ отвечает на /api/health"
  fail "Ответ: $HEALTH"
fi

# Через nginx
HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" http://localhost/api/health 2>/dev/null || echo "000")
if [[ "$HTTP_CODE" == "200" ]]; then
  ok "Nginx проксирует /api/ → backend (HTTP $HTTP_CODE)"
else
  fail "Nginx НЕ проксирует /api/ (HTTP $HTTP_CODE)"
  warn "Перепроверяем nginx конфиг..."
fi

# ── 6. Nginx конфиг ──────────────────────────────────────────────────────────
step "Nginx конфиг"

if [[ -f /etc/nginx/sites-enabled/edusystem ]]; then
  ok "Конфиг /etc/nginx/sites-enabled/edusystem существует"
  nginx -t 2>&1 | grep -q "successful" && ok "nginx -t: конфиг валиден" || fail "nginx -t: ОШИБКА в конфиге"
else
  fail "Конфиг nginx НЕ найден в sites-enabled"

  if [[ -f /etc/nginx/sites-available/edusystem ]]; then
    warn "Конфиг есть в sites-available, но нет симлинка → создаём"
    ln -sf /etc/nginx/sites-available/edusystem /etc/nginx/sites-enabled/edusystem
    systemctl reload nginx && ok "Nginx перезагружен"
  else
    fail "Конфиг отсутствует полностью → нужна переустановка"
  fi
fi

# Проверяем что root указывает на собранный dist
NGINX_ROOT=$(grep -oP '(?<=root ).*(?=;)' /etc/nginx/sites-available/edusystem 2>/dev/null | head -1 || echo "")
if [[ -n "$NGINX_ROOT" ]]; then
  [[ -f "${NGINX_ROOT}/index.html" ]] && ok "root путь nginx валиден: $NGINX_ROOT" \
    || fail "root путь nginx указывает на несуществующую директорию: $NGINX_ROOT"
fi

# ── 7. Последние логи backend ─────────────────────────────────────────────────
step "Последние 30 строк лога backend"

if [[ -f "$LOG" ]]; then
  tail -30 "$LOG"
else
  warn "Лог-файл $LOG не найден, показываем pm2 logs:"
  pm2 logs edusystem-backend --lines 30 --nostream 2>/dev/null || true
fi

# ── Итог ──────────────────────────────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Диагностика завершена."
echo "Если проблема не решена — скопируйте вывод выше"
echo "и отправьте для дальнейшего разбора."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
