import Fastify from 'fastify'
import cors from '@fastify/cors'
import jwt from '@fastify/jwt'
import { PrismaClient } from '@prisma/client'
import { authRoutes }     from './routes/auth.js'
import { adminRoutes }    from './routes/admin.js'
import { teacherRoutes }  from './routes/teacher.js'
import { studentRoutes }  from './routes/student.js'
import { scheduleRoutes } from './routes/schedule.js'

declare module 'fastify' { interface FastifyInstance { prisma: PrismaClient } }

const app    = Fastify({ logger: true })
const prisma = new PrismaClient()
app.decorate('prisma', prisma)

await app.register(cors, { origin: true, credentials: true })
await app.register(jwt, { secret: process.env.JWT_SECRET || 'dev-secret' })
await app.register(authRoutes,    { prefix: '/api/auth' })
await app.register(adminRoutes,   { prefix: '/api/admin' })
await app.register(teacherRoutes, { prefix: '/api/teacher' })
await app.register(studentRoutes, { prefix: '/api/student' })
await app.register(scheduleRoutes,{ prefix: '/api/schedule' })
app.get('/api/health', async () => ({ status: 'ok', time: new Date().toISOString() }))

const graceful = async () => { await app.close(); await prisma.$disconnect(); process.exit(0) }
process.on('SIGINT', graceful); process.on('SIGTERM', graceful)

await app.listen({ port: Number(process.env.PORT) || 3000, host: '0.0.0.0' })
