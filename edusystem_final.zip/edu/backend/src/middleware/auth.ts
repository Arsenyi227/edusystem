import type { FastifyRequest, FastifyReply } from 'fastify'
export type JwtPayload = { id: number; role: 'ADMIN' | 'TEACHER' | 'STUDENT'; name: string }
export function requireAuth(roles?: JwtPayload['role'][]) {
  return async (req: FastifyRequest, reply: FastifyReply) => {
    try {
      await req.jwtVerify()
      const user = req.user as JwtPayload
      if (roles && !roles.includes(user.role)) return reply.status(403).send({ error: 'Forbidden' })
    } catch { return reply.status(401).send({ error: 'Unauthorized' }) }
  }
}
