import type { FastifyInstance } from 'fastify'
import { requireAuth, type JwtPayload } from '../middleware/auth.js'
import { generateSchedule } from '../services/scheduler.js'

export async function scheduleRoutes(app: FastifyInstance) {
  const guard = { preHandler: requireAuth() }

  app.get('/group/:groupId', guard, async (req) =>
    app.prisma.scheduleEntry.findMany({
      where: { groupId: Number((req.params as any).groupId) },
      include: { teacher: { include: { user: { select: { name: true } } } }, subject: true, group: true },
      orderBy: [{ dayOfWeek: 'asc' }, { lessonNum: 'asc' }],
    })
  )

  app.get('/my', { preHandler: requireAuth(['TEACHER', 'ADMIN']) }, async (req) => {
    const t = await app.prisma.teacher.findUnique({ where: { userId: (req.user as JwtPayload).id } })
    if (!t) return []
    return app.prisma.scheduleEntry.findMany({
      where: { teacherId: t.id },
      include: { subject: true, group: true },
      orderBy: [{ dayOfWeek: 'asc' }, { lessonNum: 'asc' }],
    })
  })

  app.get('/student', { preHandler: requireAuth(['STUDENT']) }, async (req) => {
    const s = await app.prisma.student.findUnique({ where: { userId: (req.user as JwtPayload).id } })
    if (!s) return []
    return app.prisma.scheduleEntry.findMany({
      where: { groupId: s.groupId },
      include: { teacher: { include: { user: { select: { name: true } } } }, subject: true },
      orderBy: [{ dayOfWeek: 'asc' }, { lessonNum: 'asc' }],
    })
  })

  app.post('/generate', { preHandler: requireAuth(['ADMIN']) }, async (req, reply) => {
    const assignments = await app.prisma.teacherSubjectGroup.findMany()
    if (!assignments.length) return reply.status(400).send({ error: 'Нет записей расчасовки. Заполните расчасовку сначала.' })
    const slots = generateSchedule(assignments.map(a => ({ teacherId: a.teacherId, subjectId: a.subjectId, groupId: a.groupId, hoursPerWeek: a.hoursPerWeek })))
    await app.prisma.$transaction([app.prisma.scheduleEntry.deleteMany(), app.prisma.scheduleEntry.createMany({ data: slots })])
    return { generated: slots.length, message: `Расписание сгенерировано: ${slots.length} занятий` }
  })

  app.delete('/clear', { preHandler: requireAuth(['ADMIN']) }, async (_, reply) => {
    await app.prisma.scheduleEntry.deleteMany()
    return reply.status(204).send()
  })

  app.get('/groups', guard, async () => app.prisma.group.findMany({ orderBy: { name: 'asc' } }))
}
