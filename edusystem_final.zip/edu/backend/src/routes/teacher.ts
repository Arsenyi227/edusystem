import type { FastifyInstance } from 'fastify'
import { requireAuth, type JwtPayload } from '../middleware/auth.js'

export async function teacherRoutes(app: FastifyInstance) {
  const guard = { preHandler: requireAuth(['TEACHER', 'ADMIN']) }

  async function getTeacher(userId: number) {
    return app.prisma.teacher.upsert({ where: { userId }, update: {}, create: { userId } })
  }

  app.get('/my-subjects', guard, async (req) => {
    const t = await getTeacher((req.user as JwtPayload).id)
    return app.prisma.teacherSubjectGroup.findMany({
      where: { teacherId: t.id },
      include: { subject: true, group: { include: { students: { include: { user: { select: { name: true } } } } } } },
    })
  })

  app.post('/my-subjects', guard, async (req, reply) => {
    const t = await getTeacher((req.user as JwtPayload).id)
    const { subjectId, groupId, hoursPerWeek } = req.body as any
    const row = await app.prisma.teacherSubjectGroup.upsert({
      where: { teacherId_subjectId_groupId: { teacherId: t.id, subjectId, groupId } },
      update: { hoursPerWeek },
      create: { teacherId: t.id, subjectId, groupId, hoursPerWeek },
      include: { subject: true, group: true },
    })
    return reply.status(201).send(row)
  })

  app.delete('/my-subjects/:id', guard, async (req, reply) => {
    await app.prisma.teacherSubjectGroup.delete({ where: { id: Number((req.params as any).id) } })
    return reply.status(204).send()
  })

  app.get('/grades', guard, async (req) => {
    const { groupId, subjectId } = req.query as any
    return app.prisma.grade.findMany({
      where: { ...(subjectId ? { subjectId: Number(subjectId) } : {}), ...(groupId ? { student: { groupId: Number(groupId) } } : {}) },
      include: { student: { include: { user: { select: { name: true } } } }, subject: true },
      orderBy: { date: 'desc' },
    })
  })

  app.post('/grades', guard, async (req, reply) => {
    const t = await getTeacher((req.user as JwtPayload).id)
    const { studentId, subjectId, value, comment } = req.body as any
    if (value < 1 || value > 5) return reply.status(400).send({ error: 'Value 1-5' })
    return reply.status(201).send(await app.prisma.grade.create({
      data: { studentId, subjectId, teacherId: t.id, value, comment },
      include: { student: { include: { user: { select: { name: true } } } }, subject: true },
    }))
  })

  app.delete('/grades/:id', guard, async (req, reply) => {
    await app.prisma.grade.delete({ where: { id: Number((req.params as any).id) } })
    return reply.status(204).send()
  })

  app.get('/attendance', guard, async (req) => {
    const { groupId, date } = req.query as any
    const where: any = {}
    if (groupId) where.student = { groupId: Number(groupId) }
    if (date) { const d = new Date(date), n = new Date(d); n.setDate(n.getDate() + 1); where.date = { gte: d, lt: n } }
    return app.prisma.attendance.findMany({ where, include: { student: { include: { user: { select: { name: true } } } } }, orderBy: { date: 'desc' } })
  })

  app.post('/attendance', guard, async (req, reply) => {
    const items = req.body as any[]
    return reply.status(201).send(await Promise.all(items.map(i =>
      app.prisma.attendance.upsert({
        where: { studentId_date_lessonNum: { studentId: i.studentId, date: new Date(i.date), lessonNum: i.lessonNum } },
        update: { present: i.present }, create: { studentId: i.studentId, date: new Date(i.date), lessonNum: i.lessonNum, present: i.present },
      })
    )))
  })

  app.get('/assignments', guard, async (req) => {
    const t = await getTeacher((req.user as JwtPayload).id)
    return app.prisma.assignment.findMany({ where: { teacherId: t.id }, include: { subject: true, group: true }, orderBy: { dueDate: 'asc' } })
  })

  app.post('/assignments', guard, async (req, reply) => {
    const t = await getTeacher((req.user as JwtPayload).id)
    const { subjectId, groupId, title, description, dueDate } = req.body as any
    return reply.status(201).send(await app.prisma.assignment.create({
      data: { teacherId: t.id, subjectId, groupId, title, description, dueDate: new Date(dueDate) },
      include: { subject: true, group: true },
    }))
  })

  app.delete('/assignments/:id', guard, async (req, reply) => {
    await app.prisma.assignment.delete({ where: { id: Number((req.params as any).id) } })
    return reply.status(204).send()
  })

  app.get('/form-data', guard, async () => {
    const [groups, subjects] = await Promise.all([
      app.prisma.group.findMany({ orderBy: { name: 'asc' } }),
      app.prisma.subject.findMany({ orderBy: { name: 'asc' } }),
    ])
    return { groups, subjects }
  })
}
