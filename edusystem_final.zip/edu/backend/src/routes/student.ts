import type { FastifyInstance } from 'fastify'
import { requireAuth, type JwtPayload } from '../middleware/auth.js'

export async function studentRoutes(app: FastifyInstance) {
  const guard = { preHandler: requireAuth(['STUDENT', 'TEACHER', 'ADMIN']) }
  app.get('/diary', guard, async (req) => {
    const { id } = req.user as JwtPayload
    const s = await app.prisma.student.findUnique({ where: { userId: id }, include: { group: true } })
    if (!s) return { student: null, grades: [], assignments: [] }
    const [grades, assignments] = await Promise.all([
      app.prisma.grade.findMany({ where: { studentId: s.id }, include: { subject: true, teacher: { include: { user: { select: { name: true } } } } }, orderBy: { date: 'desc' } }),
      app.prisma.assignment.findMany({ where: { groupId: s.groupId }, include: { subject: true, teacher: { include: { user: { select: { name: true } } } } }, orderBy: { dueDate: 'asc' } }),
    ])
    return { student: s, grades, assignments }
  })
  app.get('/attendance', guard, async (req) => {
    const { id } = req.user as JwtPayload
    const s = await app.prisma.student.findUnique({ where: { userId: id } })
    if (!s) return []
    return app.prisma.attendance.findMany({ where: { studentId: s.id }, orderBy: { date: 'desc' } })
  })
}
