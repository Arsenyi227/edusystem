import type { FastifyInstance } from 'fastify'
import bcrypt from 'bcryptjs'
import { requireAuth } from '../middleware/auth.js'

export async function adminRoutes(app: FastifyInstance) {
  const guard = { preHandler: requireAuth(['ADMIN']) }

  // ── Users ──────────────────────────────────────────────────────────────────
  app.get('/users', guard, async () =>
    app.prisma.user.findMany({
      select: { id: true, name: true, email: true, role: true, createdAt: true,
        student: { select: { id: true, group: { select: { id: true, name: true } } } },
        teacher: { select: { id: true } },
      },
      orderBy: { createdAt: 'desc' },
    })
  )

  app.post('/users', guard, async (req, reply) => {
    const { email, password, name, role, groupId, subjectIds } = req.body as {
      email: string; password: string; name: string
      role: 'TEACHER' | 'STUDENT'; groupId?: number; subjectIds?: number[]
    }
    if (!email || !password || !name || !role) return reply.status(400).send({ error: 'Missing fields' })
    const hash = await bcrypt.hash(password, 10)
    const user = await app.prisma.user.create({
      data: {
        email, password: hash, name, role,
        teacher: role === 'TEACHER' ? { create: {} } : undefined,
        student: role === 'STUDENT' && groupId ? { create: { groupId } } : undefined,
      },
      select: { id: true, name: true, email: true, role: true, teacher: { select: { id: true } } },
    })
    return reply.status(201).send(user)
  })

  app.patch('/users/:id', guard, async (req, reply) => {
    const id = Number((req.params as any).id)
    const { name, email, password, groupId } = req.body as any
    const data: any = {}
    if (name) data.name = name
    if (email) data.email = email
    if (password) data.password = await bcrypt.hash(password, 10)
    const user = await app.prisma.user.update({ where: { id }, data })
    if (groupId) await app.prisma.student.updateMany({ where: { userId: id }, data: { groupId: Number(groupId) } })
    return user
  })

  app.delete('/users/:id', guard, async (req, reply) => {
    await app.prisma.user.delete({ where: { id: Number((req.params as any).id) } })
    return reply.status(204).send()
  })

  // ── Groups ─────────────────────────────────────────────────────────────────
  app.get('/groups', guard, async () =>
    app.prisma.group.findMany({ include: { _count: { select: { students: true } } }, orderBy: { name: 'asc' } })
  )
  app.post('/groups', guard, async (req, reply) => {
    const { name } = req.body as any
    return reply.status(201).send(await app.prisma.group.create({ data: { name } }))
  })
  app.delete('/groups/:id', guard, async (req, reply) => {
    await app.prisma.group.delete({ where: { id: Number((req.params as any).id) } })
    return reply.status(204).send()
  })

  // ── Subjects ───────────────────────────────────────────────────────────────
  app.get('/subjects', guard, async () =>
    app.prisma.subject.findMany({ orderBy: { name: 'asc' } })
  )
  app.post('/subjects', guard, async (req, reply) => {
    const { name } = req.body as any
    return reply.status(201).send(await app.prisma.subject.create({ data: { name } }))
  })
  app.delete('/subjects/:id', guard, async (req, reply) => {
    await app.prisma.subject.delete({ where: { id: Number((req.params as any).id) } })
    return reply.status(204).send()
  })

  // ── Stats ──────────────────────────────────────────────────────────────────
  app.get('/stats', guard, async () => {
    const [students, teachers, groups, subjects] = await Promise.all([
      app.prisma.student.count(), app.prisma.teacher.count(),
      app.prisma.group.count(), app.prisma.subject.count(),
    ])
    return { students, teachers, groups, subjects }
  })

  // ── Workload (TeacherSubjectGroup) — полное управление от администратора ──
  app.get('/workload', guard, async () =>
    app.prisma.teacherSubjectGroup.findMany({
      include: {
        teacher: { include: { user: { select: { id: true, name: true } } } },
        subject: true,
        group: { include: { students: { include: { user: { select: { name: true } } } } } },
      },
      orderBy: [{ subject: { name: 'asc' } }, { group: { name: 'asc' } }],
    })
  )

  // Данные для формы расчасовки
  app.get('/workload/form-data', guard, async () => {
    const [teachers, subjects, groups] = await Promise.all([
      app.prisma.teacher.findMany({
        include: { user: { select: { id: true, name: true } } },
        orderBy: { user: { name: 'asc' } },
      }),
      app.prisma.subject.findMany({ orderBy: { name: 'asc' } }),
      app.prisma.group.findMany({ orderBy: { name: 'asc' } }),
    ])
    return { teachers, subjects, groups }
  })

  // Создать / обновить запись нагрузки
  app.post('/workload', guard, async (req, reply) => {
    const { teacherId, subjectId, groupId, hoursPerWeek } = req.body as any
    const row = await app.prisma.teacherSubjectGroup.upsert({
      where: { teacherId_subjectId_groupId: { teacherId: Number(teacherId), subjectId: Number(subjectId), groupId: Number(groupId) } },
      update: { hoursPerWeek: Number(hoursPerWeek) },
      create: { teacherId: Number(teacherId), subjectId: Number(subjectId), groupId: Number(groupId), hoursPerWeek: Number(hoursPerWeek) },
      include: { teacher: { include: { user: { select: { name: true } } } }, subject: true, group: true },
    })
    return reply.status(201).send(row)
  })

  // Изменить преподавателя или часы в существующей записи
  app.patch('/workload/:id', guard, async (req) => {
    const { teacherId, hoursPerWeek } = req.body as any
    return app.prisma.teacherSubjectGroup.update({
      where: { id: Number((req.params as any).id) },
      data: {
        ...(teacherId    ? { teacherId: Number(teacherId) }       : {}),
        ...(hoursPerWeek ? { hoursPerWeek: Number(hoursPerWeek) } : {}),
      },
      include: { teacher: { include: { user: { select: { name: true } } } }, subject: true, group: true },
    })
  })

  app.delete('/workload/:id', guard, async (req, reply) => {
    await app.prisma.teacherSubjectGroup.delete({ where: { id: Number((req.params as any).id) } })
    return reply.status(204).send()
  })
}
