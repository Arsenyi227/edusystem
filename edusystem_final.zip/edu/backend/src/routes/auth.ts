import type { FastifyInstance } from 'fastify'
import bcrypt from 'bcryptjs'
export async function authRoutes(app: FastifyInstance) {
  app.post('/login', async (req, reply) => {
    const { email, password } = req.body as any
    if (!email || !password) return reply.status(400).send({ error: 'Required' })
    const user = await app.prisma.user.findUnique({ where: { email } })
    if (!user || !(await bcrypt.compare(password, user.password))) return reply.status(401).send({ error: 'Invalid credentials' })
    const token = app.jwt.sign({ id: user.id, role: user.role, name: user.name }, { expiresIn: '24h' })
    return { token, user: { id: user.id, role: user.role, name: user.name } }
  })
}
