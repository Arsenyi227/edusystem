export interface AssignmentInput { teacherId: number; subjectId: number; groupId: number; hoursPerWeek: number }
export interface ScheduledLesson { teacherId: number; subjectId: number; groupId: number; dayOfWeek: number; lessonNum: number }

export function generateSchedule(assignments: AssignmentInput[]): ScheduledLesson[] {
  const groupSlots   = new Set<string>()
  const teacherSlots = new Set<string>()
  const result: ScheduledLesson[] = []
  const DAYS = [1, 2, 3, 4, 5]

  const byGroup = new Map<number, AssignmentInput[]>()
  for (const a of assignments) {
    if (!byGroup.has(a.groupId)) byGroup.set(a.groupId, [])
    byGroup.get(a.groupId)!.push(a)
  }

  for (const [groupId, groupAssignments] of byGroup) {
    const toPlace: AssignmentInput[] = []
    for (const a of groupAssignments) {
      for (let i = 0; i < a.hoursPerWeek; i++) toPlace.push(a)
    }

    const dayCount = new Map<number, number>(DAYS.map(d => [d, 0]))

    for (const a of toPlace) {
      const daysSorted = [...DAYS].sort((x, y) => (dayCount.get(x) ?? 0) - (dayCount.get(y) ?? 0))
      let placed = false
      for (const day of daysSorted) {
        if (placed) break
        for (let lessonNum = 1; lessonNum <= 6; lessonNum++) {
          const gSlot = `g${groupId}-d${day}-l${lessonNum}`
          const tSlot = `t${a.teacherId}-d${day}-l${lessonNum}`
          if (!groupSlots.has(gSlot) && !teacherSlots.has(tSlot)) {
            groupSlots.add(gSlot); teacherSlots.add(tSlot)
            dayCount.set(day, (dayCount.get(day) ?? 0) + 1)
            result.push({ teacherId: a.teacherId, subjectId: a.subjectId, groupId: a.groupId, dayOfWeek: day, lessonNum })
            placed = true; break
          }
        }
      }
    }

    // Уплотнение: убираем пустые слоты в начале каждого дня
    for (const day of DAYS) {
      const dayLessons = result
        .filter(r => r.groupId === groupId && r.dayOfWeek === day)
        .sort((a, b) => a.lessonNum - b.lessonNum)
      dayLessons.forEach((lesson, idx) => {
        const newNum = idx + 1
        if (newNum !== lesson.lessonNum) {
          groupSlots.delete(`g${groupId}-d${day}-l${lesson.lessonNum}`)
          teacherSlots.delete(`t${lesson.teacherId}-d${day}-l${lesson.lessonNum}`)
          groupSlots.add(`g${groupId}-d${day}-l${newNum}`)
          teacherSlots.add(`t${lesson.teacherId}-d${day}-l${newNum}`)
          lesson.lessonNum = newNum
        }
      })
    }
  }

  return result
}
