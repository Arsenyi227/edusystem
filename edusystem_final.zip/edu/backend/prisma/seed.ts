import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
const prisma = new PrismaClient()
async function main() {
  const h = (p: string) => bcrypt.hash(p, 10)
  await prisma.user.upsert({ where: { email: 'admin@school.kz' }, update: {}, create: { email: 'admin@school.kz', password: await h('admin123'), name: 'Администратор', role: 'ADMIN' } })
  const tUser = await prisma.user.upsert({ where: { email: 'teacher@school.kz' }, update: {}, create: { email: 'teacher@school.kz', password: await h('teacher123'), name: 'Иванова Мария Ивановна', role: 'TEACHER' } })
  const teacher = await prisma.teacher.upsert({ where: { userId: tUser.id }, update: {}, create: { userId: tUser.id } })
  const group = await prisma.group.upsert({ where: { name: '10А' }, update: {}, create: { name: '10А' } })
  const math = await prisma.subject.upsert({ where: { name: 'Математика' }, update: {}, create: { name: 'Математика' } })
  const phys = await prisma.subject.upsert({ where: { name: 'Физика' }, update: {}, create: { name: 'Физика' } })
  const sUser = await prisma.user.upsert({ where: { email: 'student@school.kz' }, update: {}, create: { email: 'student@school.kz', password: await h('student123'), name: 'Петров Иван', role: 'STUDENT' } })
  const student = await prisma.student.upsert({ where: { userId: sUser.id }, update: {}, create: { userId: sUser.id, groupId: group.id } })
  await prisma.teacherSubjectGroup.upsert({ where: { teacherId_subjectId_groupId: { teacherId: teacher.id, subjectId: math.id, groupId: group.id } }, update: {}, create: { teacherId: teacher.id, subjectId: math.id, groupId: group.id, hoursPerWeek: 3 } })
  await prisma.teacherSubjectGroup.upsert({ where: { teacherId_subjectId_groupId: { teacherId: teacher.id, subjectId: phys.id, groupId: group.id } }, update: {}, create: { teacherId: teacher.id, subjectId: phys.id, groupId: group.id, hoursPerWeek: 2 } })
  await prisma.grade.create({ data: { studentId: student.id, subjectId: math.id, teacherId: teacher.id, value: 5, comment: 'Отлично' } }).catch(() => {})
  console.log('✓ Seed done\n  admin@school.kz / admin123\n  teacher@school.kz / teacher123\n  student@school.kz / student123')
}
main().finally(() => prisma.$disconnect())
